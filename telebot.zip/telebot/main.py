#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import subprocess
import telebot
from telebot.types import InlineKeyboardButton, InlineKeyboardMarkup
from datetime import datetime, timedelta
import zipfile
import shutil
import logging
import time
import threading
import tempfile
import sqlite3
import re
import psutil
import hashlib
import base64
import json
import requests
import io
from cryptography.fernet import Fernet 

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('hosting.log', encoding='utf-8')
    ]
)
logger = logging.getLogger(__name__)

BOT_TOKEN ='7961176812:AAGSic_ukk8Lld0Xwb0HKxI1KT3_gtQxqgg'
ADMIN_IDS = [7055215959]
DEVELOPER_USERNAME = "@e1mox"
GEMINI_API_KEY = 'AIzaSyBkaR0h8bZS4UntskAQFKrlwA8R_PLWrzA'
DEEPSEEK_API_KEY = 'sk-3b9237fdcc34430096ed329ac876254c'
FORCE_CHANNEL = "@emoxxera"
FORCE_CHANNEL_ID = -1002236303233

COST_PER_SCRIPT = 5
COST_PER_ZIP = 10
REFERRAL_POINTS = 10
MAX_FILE_SIZE = 20 * 1024 * 1024
INITIAL_POINTS = 10
DAILY_POINTS = 5
PREMIUM_COST = 100
CREATE_BOT_COST = 200

PROJECTS_DIR = "hosted_projects"
DATABASE_FILE = "hosting.db"
BACKUP_DIR = "backups"
ENCRYPTION_KEY_FILE = "encryption.key"

os.makedirs(PROJECTS_DIR, exist_ok=True)
os.makedirs(BACKUP_DIR, exist_ok=True)

if not os.path.exists(ENCRYPTION_KEY_FILE):
    key = Fernet.generate_key()
    with open(ENCRYPTION_KEY_FILE, 'wb') as f:
        f.write(key)

with open(ENCRYPTION_KEY_FILE, 'rb') as f:
    ENCRYPTION_KEY = f.read()

cipher_suite = Fernet(ENCRYPTION_KEY)

bot = telebot.TeleBot(BOT_TOKEN)

class AdvancedAIAnalyzer:
    """AI analyzer with DeepSeek fallback and multi-source learning"""

    def __init__(self, gemini_key: str, deepseek_key: str):
        self.gemini_key = gemini_key
        self.deepseek_key = deepseek_key
        self.gemini_url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent"
        self.deepseek_url = "https://api.deepseek.com/v1/chat/completions"
        self.learning_history_file = "ai_learning_history.json"
        self.auto_learning_enabled = True
        self.init_learning_history()

    def init_learning_history(self):
        """Initialize learning history"""
        try:
            if not os.path.exists(self.learning_history_file):
                with open(self.learning_history_file, 'w') as f:
                    json.dump({
                        'learning_events': [],
                        'sources_learned': {
                            'wikipedia': 0,
                            'github': 0,
                            'reddit': 0,
                            'manual_files': 0,
                            'google_search': 0
                        },
                        'total_patterns': 0,
                        'last_learning': None
                    }, f, indent=2)
        except Exception as e:
            logger.error(f"Error initializing learning history: {str(e)}")

    def log_learning_event(self, source: str, patterns_learned: list, summary: str):
        """Log learning event and notify admins"""
        try:
            with open(self.learning_history_file, 'r') as f:
                history = json.load(f)
            
            event = {
                'timestamp': datetime.now().isoformat(),
                'source': source,
                'patterns_count': len(patterns_learned),
                'patterns': patterns_learned[:5],
                'summary': summary
            }
            
            history['learning_events'].insert(0, event)
            history['learning_events'] = history['learning_events'][:100]
            history['sources_learned'][source] = history['sources_learned'].get(source, 0) + 1
            history['total_patterns'] += len(patterns_learned)
            history['last_learning'] = datetime.now().isoformat()
            
            with open(self.learning_history_file, 'w') as f:
                json.dump(history, f, indent=2)
            
            # Notify admins with enhanced message
            for admin_id in ADMIN_IDS:
                try:
                    msg = "🧠 <b>AI تعلم شيء جديد!</b>\n"
                    msg += "━━━━━━━━━━━━━━━━━━━\n"
                    msg += f"📚 <b>المصدر:</b> {source.upper()}\n"
                    msg += f"🎯 <b>أنماط جديدة:</b> {len(patterns_learned)}\n"
                    msg += f"📊 <b>إجمالي الأنماط:</b> {history['total_patterns']}\n"
                    msg += f"📝 <b>ملخص:</b> {summary[:150]}...\n"
                    msg += f"⏰ <b>الوقت:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                    msg += "━━━━━━━━━━━━━━━━━━━\n"
                    msg += "✅ <b>التعلم مستمر تلقائياً!</b>"
                    bot.send_message(admin_id, msg, parse_mode='HTML')
                except:
                    pass
                    
        except Exception as e:
            logger.error(f"Error logging learning event: {str(e)}")

    def search_google(self, query: str) -> list:
        """Search Google without API key using HTML scraping"""
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            url = f"https://www.google.com/search?q={query}"
            response = requests.get(url, headers=headers, timeout=10)
            
            # Simple extraction of search results (basic scraping)
            results = []
            if response.status_code == 200:
                # Extract snippets from search results
                import re
                snippets = re.findall(r'<div class="VwiC3b[^"]*"[^>]*>([^<]+)</div>', response.text)
                results = snippets[:5]
            
            return results
        except Exception as e:
            logger.error(f"Google search error: {str(e)}")
            return []

    def learn_from_wikipedia(self, topic: str) -> list:
        """Learn security patterns from Wikipedia"""
        try:
            url = f"https://en.wikipedia.org/api/rest_v1/page/summary/{topic}"
            logger.debug(f"Fetching Wikipedia: {url}")
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
            response = requests.get(url, headers=headers, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                content = data.get('extract', '')
                logger.debug(f"Wikipedia content length: {len(content)}")
                
                # Ask AI to extract security patterns
                prompt = f"Analyze this Wikipedia content about {topic} and extract cybersecurity threat patterns.\n"
                prompt += f"Content: {content[:1500]}\n"
                prompt += "Return JSON: {\"patterns\": [\"pattern1\", \"pattern2\"], \"summary\": \"brief summary\"}"

                logger.debug("Asking DeepSeek to analyze Wikipedia content...")
                result = self._ask_deepseek(prompt)
                if result:
                    patterns = result.get('patterns', [])
                    summary = result.get('summary', 'No summary')
                    logger.info(f"DeepSeek extracted {len(patterns)} patterns from Wikipedia")
                    self.log_learning_event('wikipedia', patterns, f"Learned from Wikipedia: {topic} - {summary}")
                    return patterns
                else:
                    logger.warning("DeepSeek returned None for Wikipedia")
            else:
                logger.warning(f"Wikipedia API returned status {response.status_code}")
        except Exception as e:
            logger.error(f"Wikipedia learning error: {str(e)}", exc_info=True)
        return []

    def learn_from_github(self, repo_query: str) -> list:
        """Learn from GitHub security repos"""
        try:
            # Search GitHub for security-related code
            url = f"https://api.github.com/search/code?q={repo_query}+security+language:python"
            headers = {'Accept': 'application/vnd.github.v3+json'}
            response = requests.get(url, headers=headers, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                items = data.get('items', [])[:3]
                
                patterns = []
                for item in items:
                    # Analyze file content
                    file_url = item.get('url', '')
                    if file_url:
                        file_response = requests.get(file_url, headers=headers, timeout=10)
                        if file_response.status_code == 200:
                            content = file_response.json().get('content', '')
                            # Decode base64
                            try:
                                decoded = base64.b64decode(content).decode('utf-8')
                                # Extract patterns using AI
                                prompt = "Extract security threat patterns from this code:\n"
                                prompt += f"{decoded[:1000]}\n"
                                prompt += "Return JSON: {\"patterns\": [\"regex1\", \"regex2\"]}"
                                result = self._ask_deepseek(prompt)
                                if result:
                                    patterns.extend(result.get('patterns', []))
                            except:
                                pass
                
                if patterns:
                    self.log_learning_event('github', patterns, f"Learned from GitHub: {repo_query}")
                return patterns
        except Exception as e:
            logger.error(f"GitHub learning error: {str(e)}")
        return []

    def learn_from_reddit(self, subreddit: str) -> list:
        """Learn from Reddit security discussions"""
        try:
            url = f"https://www.reddit.com/r/{subreddit}/hot.json?limit=10"
            headers = {'User-Agent': 'Mozilla/5.0'}
            response = requests.get(url, headers=headers, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                posts = data.get('data', {}).get('children', [])
                
                content_samples = []
                for post in posts:
                    post_data = post.get('data', {})
                    title = post_data.get('title', '')
                    selftext = post_data.get('selftext', '')
                    content_samples.append(f"{title}\n{selftext[:200]}")
                
                combined = '\n\n'.join(content_samples[:5])
                
                prompt = "Analyze these Reddit security discussions and extract threat patterns:\n"
                prompt += f"{combined}\n"
                prompt += "Return JSON: {\"patterns\": [\"pattern1\", \"pattern2\"], \"summary\": \"what learned\"}"

                result = self._ask_deepseek(prompt)
                if result:
                    patterns = result.get('patterns', [])
                    self.log_learning_event('reddit', patterns, f"Learned from r/{subreddit}")
                    return patterns
        except Exception as e:
            logger.error(f"Reddit learning error: {str(e)}")
        return []

    def analyze_manual_file(self, file_content: str, filename: str) -> dict:
        """Analyze manually uploaded file with DeepSeek"""
        try:
            # First analysis
            prompt = "Analyze this file for security threats. It's from manual training.\n"
            prompt += f"File: {filename}\n"
            prompt += "Content (first 2000 chars):\n"
            prompt += f"{file_content[:2000]}\n"
            prompt += "Provide detailed analysis:\n"
            prompt += "1. What type of threats does it contain?\n"
            prompt += "2. What patterns can we learn?\n"
            prompt += "3. How dangerous is it?\n"
            prompt += "Return JSON: {\"threat_type\": \"type\", \"patterns\": [\"p1\", \"p2\"], \"severity\": \"critical/high/medium/low\", \"explanation\": \"detailed\"}"

            result = self._ask_deepseek(prompt)
            
            if result:
                patterns = result.get('patterns', [])
                self.log_learning_event('manual_files', patterns, 
                    f"Manual file analysis: {filename} - {result.get('explanation', '')[:100]}")
            
            return result or {}
        except Exception as e:
            logger.error(f"Manual file analysis error: {str(e)}")
            return {}

    def _ask_deepseek(self, prompt: str) -> dict:
        """Ask DeepSeek AI and return JSON response"""
        if not self.deepseek_key:
            return None
        
        try:
            headers = {
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {self.deepseek_key}'
            }
            payload = {
                "model": "deepseek-chat",
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.2,
                "max_tokens": 1000
            }
            response = requests.post(self.deepseek_url, headers=headers, json=payload, timeout=20)
            
            if response.status_code == 200:
                result = response.json()
                text = result.get('choices', [{}])[0].get('message', {}).get('content', '')
                text = text.strip()
                if '```json' in text:
                    text = text.split('```json')[1].split('```')[0]
                elif '```' in text:
                    text = text.split('```')[1].split('```')[0]
                
                return json.loads(text.strip())
        except Exception as e:
            logger.error(f"DeepSeek API error: {str(e)}")
        return None

    def auto_learn_background(self):
        """Auto learning from multiple sources in background"""
        if not self.auto_learning_enabled:
            logger.info("⚠️ Auto learning is disabled")
            return
        
        logger.info("🚀 Starting auto learning from multiple sources...")
        
        try:
            # Learn from different sources
            topics = ['cybersecurity', 'malware']
            
            for topic in topics:
                # Wikipedia
                logger.info(f"📖 Learning from Wikipedia: {topic}")
                patterns = self.learn_from_wikipedia(topic)
                logger.info(f"✅ Wikipedia {topic}: {len(patterns) if patterns else 0} patterns")
                time.sleep(2)
                
                # Google Search
                logger.info(f"🔍 Learning from Google: {topic}")
                search_results = self.search_google(f"{topic} security threats")
                if search_results:
                    logger.info(f"Found {len(search_results)} search results")
                    combined = '\n'.join(search_results)
                    prompt = f"Extract security patterns from these search results about {topic}:\n"
                    prompt += f"{combined}\n"
                    prompt += "Return JSON: {\"patterns\": [\"p1\", \"p2\"]}"
                    result = self._ask_deepseek(prompt)
                    if result:
                        patterns = result.get('patterns', [])
                        logger.info(f"✅ Google {topic}: {len(patterns)} patterns")
                        self.log_learning_event('google_search', patterns, f"Google search: {topic}")
                    else:
                        logger.warning(f"⚠️ DeepSeek returned no result for Google {topic}")
                else:
                    logger.warning(f"⚠️ No search results for {topic}")
                
                time.sleep(2)
            
            # GitHub
            logger.info("💻 Learning from GitHub...")
            patterns = self.learn_from_github('malicious code detection')
            logger.info(f"✅ GitHub: {len(patterns) if patterns else 0} patterns")
            time.sleep(2)
            
            # Reddit
            for sub in ['cybersecurity']:
                logger.info(f"🌐 Learning from Reddit: r/{sub}")
                patterns = self.learn_from_reddit(sub)
                logger.info(f"✅ Reddit r/{sub}: {len(patterns) if patterns else 0} patterns")
                time.sleep(2)
            
            logger.info("🎉 Auto learning session completed!")
                
        except Exception as e:
            logger.error(f"❌ Auto learning error: {str(e)}", exc_info=True)

    def analyze_with_deepseek(self, code: str, filename: str) -> dict:
        """Analyze using DeepSeek API - Always returns a dict"""
        if not self.deepseek_key:
            return {'safe': True, 'threats': [], 'analysis': 'DeepSeek not available', 'confidence': 0, 'risk_level': 'low'}
        
        try:
            code_sample = code[:3000].encode('ascii', errors='ignore').decode('ascii')
            
            prompt = "Analyze this Python code for CRITICAL security threats. Bot hosting service context.\n"
            prompt += "CRITICAL threats to check:\n"
            prompt += "1. File operations leaking HOST files (ls, dir, listdir, walk, glob on parent dirs)\n"
            prompt += "2. send_document operations that leak files\n"
            prompt += "3. Reading files outside project directory\n"
            prompt += "4. Network operations leaking HOST data\n"
            prompt += "5. System commands accessing HOST\n"
            prompt += "BOT_TOKEN is ALLOWED in user files.\n"
            prompt += f"Code: {filename}\n"
            prompt += f"{code_sample}\n"
            prompt += "Respond JSON: {\"safe\": true/false, \"threats\": [\"list\"], \"risk_level\": \"low/medium/high/critical\"}"

            headers = {
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {self.deepseek_key}'
            }

            payload = {
                "model": "deepseek-chat",
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.1,
                "max_tokens": 1000
            }

            response = requests.post(self.deepseek_url, headers=headers, json=payload, timeout=15)

            if response.status_code == 200:
                result = response.json()
                text_result = result.get('choices', [{}])[0].get('message', {}).get('content', '')
                
                text_result = text_result.strip()
                if text_result.startswith('```json'):
                    text_result = text_result[7:]
                if text_result.startswith('```'):
                    text_result = text_result[3:]
                if text_result.endswith('```'):
                    text_result = text_result[:-3]
                text_result = text_result.strip()

                try:
                    analysis = json.loads(text_result)
                    return {
                        'safe': analysis.get('safe', False),
                        'threats': analysis.get('threats', []),
                        'risk_level': analysis.get('risk_level', 'high'),
                        'confidence': 0.85,
                        'ai_provider': 'DeepSeek'
                    }
                except:
                    return {'safe': True, 'threats': [], 'analysis': 'Parse error', 'confidence': 0.3, 'risk_level': 'low'}
            
            return {'safe': True, 'threats': [], 'analysis': 'DeepSeek no response', 'confidence': 0, 'risk_level': 'low'}
        
        except Exception as e:
            logger.error(f"DeepSeek analysis error: {str(e)}")
            return {'safe': True, 'threats': [], 'analysis': 'DeepSeek unavailable', 'confidence': 0, 'risk_level': 'low'}

    def analyze_code_with_ai(self, code: str, filename: str) -> dict:
        """Analyze code using Gemini with DeepSeek fallback"""
        try:
            code_sample = code[:3000].encode('ascii', errors='ignore').decode('ascii')

            prompt = "Analyze this Python code for CRITICAL security threats ONLY. Bot hosting service context.\n"
            prompt += "Check CRITICAL threats:\n"
            prompt += "1. File system operations leaking HOST files\n"
            prompt += "2. send_document operations\n"
            prompt += "3. Reading files outside project directory\n"
            prompt += "4. Network operations leaking HOST data\n"
            prompt += "5. System command execution\n"
            prompt += "BOT_TOKEN is ALLOWED.\n"
            prompt += f"Code: {filename}\n"
            prompt += f"{code_sample}\n"
            prompt += "JSON response: {\"safe\": true/false, \"threats\": [\"list\"], \"risk_level\": \"low/medium/high/critical\"}"

            if self.gemini_key:
                try:
                    headers = {
                        'Content-Type': 'application/json; charset=utf-8',
                        'x-goog-api-key': self.gemini_key
                    }

                    payload = {
                        "contents": [{
                            "parts": [{"text": prompt}]
                        }],
                        "generationConfig": {
                            "temperature": 0.1,
                            "maxOutputTokens": 1000
                        }
                    }

                    response = requests.post(self.gemini_url, headers=headers, json=payload, timeout=10)

                    if response.status_code == 200:
                        result = response.json()
                        text_result = result.get('candidates', [{}])[0].get('content', {}).get('parts', [{}])[0].get('text', '')

                        text_result = text_result.strip()
                        if text_result.startswith('```json'):
                            text_result = text_result[7:]
                        if text_result.startswith('```'):
                            text_result = text_result[3:]
                        if text_result.endswith('```'):
                            text_result = text_result[:-3]
                        text_result = text_result.strip()

                        try:
                            analysis = json.loads(text_result)
                            return {
                                'safe': analysis.get('safe', False),
                                'threats': analysis.get('threats', []),
                                'risk_level': analysis.get('risk_level', 'high'),
                                'confidence': 0.9,
                                'ai_provider': 'Gemini'
                            }
                        except:
                            logger.warning("Gemini parse error, trying DeepSeek")
                            return self.analyze_with_deepseek(code, filename)
                except Exception as e:
                    logger.error(f"Gemini error: {str(e)}, trying DeepSeek")
                    return self.analyze_with_deepseek(code, filename)

            return self.analyze_with_deepseek(code, filename)

        except Exception as e:
            logger.error(f"AI analysis error: {str(e)}")
            return self.analyze_with_deepseek(code, filename)

class UltraSecuritySystem:
    """Ultra advanced security system with AI learning and malicious code storage"""

    def __init__(self, ai_analyzer=None):
        self.ai_analyzer = ai_analyzer
        self.safe_patterns = [
            r"bot\.polling\(",
            r"bot\.infinity_polling\(",
            r"app\.run\(",
            r"uvicorn\.run\(",
            r"bot\.message_handler\(",
            r"bot\.callback_query_handler\(",
            r"@bot\.message_handler",
            r"@bot\.callback_query_handler",
            r"bot\.reply_to\(",
            r"bot\.send_message\(",
            r"message\.text",
            r"message\.chat\.id",
        ]
        
        self.critical_patterns = [
            # Pathlib attacks
            r"\.rglob\s*\(\s*['\"]?\*['\"]?\)",
            r"\.rglob\s*\(",
            r"Path\.cwd\(\)\.rglob",
            r"current_path\.rglob",
            r"\.glob\s*\(\s*['\"]?\*",
            r"Path\.iterdir\(\)",
            r"\.iterdir\(\)",
            # File sending
            r"send_document.*hosting",
            r"send_document.*\.\.\/",
            r"send_document.*database",
            r"send_document.*\.db",
            r"send_document.*\.key",
            r"send_document.*\.env",
            r"sendMessage.*System\s+Compromised",
            r"sendMessage.*files",
            # Directory traversal
            r"listdir\s*\(\s*['\"]?\.\.['\"]?",
            r"os\.walk\s*\(\s*['\"]?\.\.['\"]?",
            r"os\.walk\s*\(",
            r"open\s*\(\s*['\"]?/etc",
            r"open\s*\(\s*['\"]?/root",
            r"open\s*\(\s*['\"]?/",
            r"open\s*\(\s*['\"]?\.\./",
            r"glob\s*\(\s*['\"]?\.\./",
            r"Path\s*\(\s*['\"]?\.\./",
            # Dangerous paths
            r"\.\.\/.*\.py",
            r"\.\.\/.*hosted_projects",
            r"\.\.\/.*hosting\.db",
            r"hosting\.db",
            r"\.\.\/.*encryption\.key",
            r"\/hosted_projects\/",
            r"encryption\.key",
            # System operations
            r"rmdir",
            r"\.unlink\(",
            r"shutil\.rmtree",
            r"os\.remove",
            r"os\.system",
            r"subprocess\.call",
            r"subprocess\.run",
            r"subprocess\.Popen",
            # Code execution
            r"eval\s*\(",
            r"exec\s*\(",
            r"compile\s*\(",
            r"__import__\s*\(",
            # Data theft indicators
            r"steal_data",
            r"current_path.*iterdir",
            r"file_path\.read\(",
            r"content\s*=.*\.read\(\d+\)",
        ]
        self.user_violations = {}
        self.learned_patterns_file = "learned_patterns.json"
        self.malicious_codes_db = "malicious_codes.db"
        self.security_mode = "both"  # "ai_only", "script_only", or "both"
        self.language = "ar"  # "ar" or "en"
        self.init_malicious_db()
        self.load_learned_patterns()

    def init_malicious_db(self):
        """Initialize malicious codes database"""
        try:
            conn = sqlite3.connect(self.malicious_codes_db)
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS malicious_codes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    code_hash TEXT UNIQUE,
                    code_sample TEXT,
                    threat_type TEXT,
                    patterns TEXT,
                    severity TEXT,
                    learned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    times_detected INTEGER DEFAULT 1
                )
            ''')
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS security_settings (
                    id INTEGER PRIMARY KEY,
                    mode TEXT DEFAULT 'both',
                    language TEXT DEFAULT 'ar',
                    ai_learning_enabled BOOLEAN DEFAULT TRUE,
                    gemini_api_key TEXT,
                    deepseek_api_key TEXT,
                    maintenance_mode BOOLEAN DEFAULT FALSE,
                    bot_enabled BOOLEAN DEFAULT TRUE,
                    maintenance_message TEXT DEFAULT 'البوت في وضع الصيانة حالياً 🔧',
                    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ''')
            # Insert default settings if not exists
            cursor.execute('SELECT id FROM security_settings WHERE id = 1')
            if not cursor.fetchone():
                cursor.execute('INSERT INTO security_settings (id) VALUES (1)')
            conn.commit()
            conn.close()
            logger.info("Malicious codes database initialized")
        except Exception as e:
            logger.error(f"Error initializing malicious DB: {str(e)}")

    def store_malicious_code(self, code: str, threat_type: str, patterns: list, severity: str):
        """Store malicious code in database for learning"""
        try:
            code_hash = hashlib.sha256(code.encode()).hexdigest()
            code_sample = code[:500]  # Store first 500 chars
            patterns_str = json.dumps(patterns)
            
            conn = sqlite3.connect(self.malicious_codes_db)
            cursor = conn.cursor()
            
            # Check if already exists
            cursor.execute('SELECT id, times_detected FROM malicious_codes WHERE code_hash = ?', (code_hash,))
            existing = cursor.fetchone()
            
            if existing:
                # Update detection count
                cursor.execute('UPDATE malicious_codes SET times_detected = times_detected + 1 WHERE code_hash = ?', (code_hash,))
            else:
                # Insert new malicious code
                cursor.execute('''
                    INSERT INTO malicious_codes (code_hash, code_sample, threat_type, patterns, severity)
                    VALUES (?, ?, ?, ?, ?)
                ''', (code_hash, code_sample, threat_type, patterns_str, severity))
            
            conn.commit()
            conn.close()
            logger.info(f"Stored malicious code: {threat_type} - Severity: {severity}")
            
            # Trigger AI learning in background
            threading.Thread(target=self.learn_from_stored_codes, daemon=True).start()
            
        except Exception as e:
            logger.error(f"Error storing malicious code: {str(e)}")

    def learn_from_stored_codes(self):
        """Learn from stored malicious codes database"""
        if not self.ai_analyzer:
            return
        
        try:
            conn = sqlite3.connect(self.malicious_codes_db)
            cursor = conn.cursor()
            
            # Get top 10 most detected malicious codes
            cursor.execute('''
                SELECT code_sample, patterns, severity, times_detected 
                FROM malicious_codes 
                ORDER BY times_detected DESC 
                LIMIT 10
            ''')
            codes = cursor.fetchall()
            conn.close()
            
            if not codes:
                return
            
            # Create learning prompt from database
            learning_samples = []
            for code_sample, patterns_str, severity, times in codes:
                learning_samples.append({
                    'code': code_sample,
                    'patterns': json.loads(patterns_str),
                    'severity': severity,
                    'frequency': times
                })
            
            # Ask AI to analyze patterns from multiple samples
            prompt = f"Analyze these {len(learning_samples)} malicious code samples from our database.\n"
            prompt += "Extract NEW regex patterns that can detect similar threats.\n"
            prompt += "Samples:\n"
            prompt += f"{json.dumps(learning_samples, indent=2)[:2000]}\n"
            prompt += "Return JSON: {\"new_patterns\": [\"regex1\", \"regex2\"], \"threat_categories\": [\"cat1\", \"cat2\"]}"

            # Try with Gemini first
            if hasattr(self.ai_analyzer, 'gemini_key') and self.ai_analyzer.gemini_key:
                try:
                    headers = {
                        'Content-Type': 'application/json',
                        'x-goog-api-key': self.ai_analyzer.gemini_key
                    }
                    payload = {
                        "contents": [{"parts": [{"text": prompt}]}],
                        "generationConfig": {"temperature": 0.2, "maxOutputTokens": 800}
                    }
                    response = requests.post(self.ai_analyzer.gemini_url, headers=headers, json=payload, timeout=15)
                    
                    if response.status_code == 200:
                        result = response.json()
                        text = result.get('candidates', [{}])[0].get('content', {}).get('parts', [{}])[0].get('text', '')
                        text = text.strip()
                        if '```json' in text:
                            text = text.split('```json')[1].split('```')[0]
                        
                        analysis = json.loads(text.strip())
                        new_patterns = analysis.get('new_patterns', [])
                        
                        for pattern in new_patterns[:5]:  # Limit to 5 new patterns
                            self.save_learned_pattern(pattern)
                        
                        logger.info(f"AI learned {len(new_patterns)} patterns from database")
                        return
                except Exception as e:
                    logger.warning(f"Gemini database learning error: {str(e)}")
            
            # Fallback to DeepSeek
            if hasattr(self.ai_analyzer, 'deepseek_key') and self.ai_analyzer.deepseek_key:
                try:
                    headers = {
                        'Content-Type': 'application/json',
                        'Authorization': f'Bearer {self.ai_analyzer.deepseek_key}'
                    }
                    payload = {
                        "model": "deepseek-chat",
                        "messages": [{"role": "user", "content": prompt}],
                        "temperature": 0.2,
                        "max_tokens": 800
                    }
                    response = requests.post(self.ai_analyzer.deepseek_url, headers=headers, json=payload, timeout=20)
                    
                    if response.status_code == 200:
                        result = response.json()
                        text = result.get('choices', [{}])[0].get('message', {}).get('content', '')
                        text = text.strip()
                        if '```json' in text:
                            text = text.split('```json')[1].split('```')[0]
                        
                        analysis = json.loads(text.strip())
                        new_patterns = analysis.get('new_patterns', [])
                        
                        for pattern in new_patterns[:5]:
                            self.save_learned_pattern(pattern)
                        
                        logger.info(f"DeepSeek learned {len(new_patterns)} patterns from database")
                except Exception as e:
                    logger.error(f"DeepSeek database learning error: {str(e)}")
                    
        except Exception as e:
            logger.error(f"Error learning from database: {str(e)}")

    def get_security_settings(self):
        """Get current security settings"""
        try:
            conn = sqlite3.connect(self.malicious_codes_db)
            cursor = conn.cursor()
            cursor.execute('''SELECT mode, language, ai_learning_enabled, gemini_api_key, deepseek_api_key, 
                           maintenance_mode, bot_enabled, maintenance_message 
                           FROM security_settings WHERE id = 1''')
            result = cursor.fetchone()
            conn.close()
            if result:
                self.security_mode = result[0]
                self.language = result[1]
                return {
                    'mode': result[0], 
                    'language': result[1], 
                    'ai_learning': bool(result[2]),
                    'gemini_api_key': result[3],
                    'deepseek_api_key': result[4],
                    'maintenance_mode': bool(result[5]),
                    'bot_enabled': bool(result[6]),
                    'maintenance_message': result[7]
                }
            return {
                'mode': 'both', 'language': 'ar', 'ai_learning': True,
                'gemini_api_key': None, 'deepseek_api_key': None,
                'maintenance_mode': False, 'bot_enabled': True,
                'maintenance_message': 'البوت في وضع الصيانة حالياً 🔧'
            }
        except Exception as e:
            logger.error(f"Error getting security settings: {str(e)}")
            return {
                'mode': 'both', 'language': 'ar', 'ai_learning': True,
                'gemini_api_key': None, 'deepseek_api_key': None,
                'maintenance_mode': False, 'bot_enabled': True,
                'maintenance_message': 'البوت في وضع الصيانة حالياً 🔧'
            }

    def update_security_settings(self, mode: str = None, language: str = None, ai_learning: bool = None, 
                                  maintenance_mode: bool = None, bot_enabled: bool = None, 
                                  maintenance_message: str = None, gemini_api_key: str = None, 
                                  deepseek_api_key: str = None):
        """Update security settings"""
        try:
            conn = sqlite3.connect(self.malicious_codes_db)
            cursor = conn.cursor()
            
            if mode:
                self.security_mode = mode
                cursor.execute('UPDATE security_settings SET mode = ? WHERE id = 1', (mode,))
            if language:
                self.language = language
                cursor.execute('UPDATE security_settings SET language = ? WHERE id = 1', (language,))
            if ai_learning is not None:
                cursor.execute('UPDATE security_settings SET ai_learning_enabled = ? WHERE id = 1', (ai_learning,))
            if maintenance_mode is not None:
                cursor.execute('UPDATE security_settings SET maintenance_mode = ? WHERE id = 1', (maintenance_mode,))
            if bot_enabled is not None:
                cursor.execute('UPDATE security_settings SET bot_enabled = ? WHERE id = 1', (bot_enabled,))
            if maintenance_message:
                cursor.execute('UPDATE security_settings SET maintenance_message = ? WHERE id = 1', (maintenance_message,))
            if gemini_api_key:
                # Encrypt API key before storing
                encrypted_key = cipher_suite.encrypt(gemini_api_key.encode()).decode()
                cursor.execute('UPDATE security_settings SET gemini_api_key = ? WHERE id = 1', (encrypted_key,))
            if deepseek_api_key:
                # Encrypt API key before storing
                encrypted_key = cipher_suite.encrypt(deepseek_api_key.encode()).decode()
                cursor.execute('UPDATE security_settings SET deepseek_api_key = ? WHERE id = 1', (encrypted_key,))
            
            cursor.execute('UPDATE security_settings SET last_updated = CURRENT_TIMESTAMP WHERE id = 1')
            conn.commit()
            conn.close()
            logger.info(f"Security settings updated: mode={mode}, lang={language}, ai_learning={ai_learning}, maintenance={maintenance_mode}, enabled={bot_enabled}")
            return True
        except Exception as e:
            logger.error(f"Error updating security settings: {str(e)}")
            return False
    
    def get_api_keys(self):
        """Get decrypted API keys from database"""
        try:
            settings = self.get_security_settings()
            gemini_key = settings.get('gemini_api_key')
            deepseek_key = settings.get('deepseek_api_key')
            
            # Decrypt keys if they exist
            if gemini_key:
                try:
                    gemini_key = cipher_suite.decrypt(gemini_key.encode()).decode()
                except:
                    gemini_key = GEMINI_API_KEY  # Fallback to hardcoded
            else:
                gemini_key = GEMINI_API_KEY
                
            if deepseek_key:
                try:
                    deepseek_key = cipher_suite.decrypt(deepseek_key.encode()).decode()
                except:
                    deepseek_key = DEEPSEEK_API_KEY  # Fallback to hardcoded
            else:
                deepseek_key = DEEPSEEK_API_KEY
                
            return {'gemini': gemini_key, 'deepseek': deepseek_key}
        except Exception as e:
            logger.error(f"Error getting API keys: {str(e)}")
            return {'gemini': GEMINI_API_KEY, 'deepseek': DEEPSEEK_API_KEY}

    def get_malicious_codes_stats(self):
        """Get statistics about stored malicious codes"""
        try:
            conn = sqlite3.connect(self.malicious_codes_db)
            cursor = conn.cursor()
            
            cursor.execute('SELECT COUNT(*) FROM malicious_codes')
            total = cursor.fetchone()[0]
            
            cursor.execute('SELECT severity, COUNT(*) FROM malicious_codes GROUP BY severity')
            by_severity = dict(cursor.fetchall())
            
            cursor.execute('SELECT SUM(times_detected) FROM malicious_codes')
            total_detections = cursor.fetchone()[0] or 0
            
            conn.close()
            
            return {
                'total_codes': total,
                'by_severity': by_severity,
                'total_detections': total_detections
            }
        except Exception as e:
            logger.error(f"Error getting malicious codes stats: {str(e)}")
            return {'total_codes': 0, 'by_severity': {}, 'total_detections': 0}

    def load_learned_patterns(self):
        """Load AI-learned patterns from file"""
        try:
            if os.path.exists(self.learned_patterns_file):
                with open(self.learned_patterns_file, 'r') as f:
                    learned = json.load(f)
                    for pattern in learned.get('patterns', []):
                        if pattern not in self.critical_patterns:
                            self.critical_patterns.append(pattern)
                    logger.info(f"Loaded {len(learned.get('patterns', []))} learned patterns")
        except Exception as e:
            logger.error(f"Error loading learned patterns: {str(e)}")

    def save_learned_pattern(self, pattern: str):
        """Save new learned pattern"""
        try:
            learned = {'patterns': []}
            if os.path.exists(self.learned_patterns_file):
                with open(self.learned_patterns_file, 'r') as f:
                    learned = json.load(f)
            
            if pattern not in learned['patterns']:
                learned['patterns'].append(pattern)
                with open(self.learned_patterns_file, 'w') as f:
                    json.dump(learned, f, indent=2)
                
                if pattern not in self.critical_patterns:
                    self.critical_patterns.append(pattern)
                logger.info(f"AI learned new pattern: {pattern}")
        except Exception as e:
            logger.error(f"Error saving learned pattern: {str(e)}")

    def learn_from_blocked_code(self, code: str, blocked_patterns: list):
        """Ask AI to analyze blocked code and extract new patterns"""
        if not self.ai_analyzer:
            return
        
        try:
            code_sample = code[:2000].encode('ascii', errors='ignore').decode('ascii')
            
            prompt = "Analyze this BLOCKED malicious code and extract NEW dangerous patterns as regex.\n"
            prompt += f"Blocked patterns found: {blocked_patterns}\n"
            prompt += "Code:\n"
            prompt += f"{code_sample}\n"
            prompt += "Extract NEW regex patterns that could detect similar malicious code. Return ONLY patterns not in the blocked list.\n"
            prompt += "Respond JSON: {\"new_patterns\": [\"regex1\", \"regex2\"], \"explanation\": \"why dangerous\"}"

            if hasattr(self.ai_analyzer, 'gemini_key') and self.ai_analyzer.gemini_key:
                try:
                    headers = {
                        'Content-Type': 'application/json',
                        'x-goog-api-key': self.ai_analyzer.gemini_key
                    }
                    payload = {
                        "contents": [{"parts": [{"text": prompt}]}],
                        "generationConfig": {"temperature": 0.2, "maxOutputTokens": 500}
                    }
                    response = requests.post(self.ai_analyzer.gemini_url, headers=headers, json=payload, timeout=10)
                    
                    if response.status_code == 200:
                        result = response.json()
                        text = result.get('candidates', [{}])[0].get('content', {}).get('parts', [{}])[0].get('text', '')
                        text = text.strip()
                        if '```json' in text:
                            text = text.split('```json')[1].split('```')[0]
                        elif '```' in text:
                            text = text.split('```')[1].split('```')[0]
                        
                        analysis = json.loads(text.strip())
                        new_patterns = analysis.get('new_patterns', [])
                        
                        for pattern in new_patterns[:3]:
                            self.save_learned_pattern(pattern)
                        
                        logger.info(f"AI learned {len(new_patterns)} new patterns")
                        return
                except Exception as e:
                    logger.warning(f"Gemini learning error: {str(e)}, trying DeepSeek")
            
            if hasattr(self.ai_analyzer, 'deepseek_key') and self.ai_analyzer.deepseek_key:
                try:
                    headers = {
                        'Content-Type': 'application/json',
                        'Authorization': f'Bearer {self.ai_analyzer.deepseek_key}'
                    }
                    payload = {
                        "model": "deepseek-chat",
                        "messages": [{"role": "user", "content": prompt}],
                        "temperature": 0.2,
                        "max_tokens": 500
                    }
                    response = requests.post(self.ai_analyzer.deepseek_url, headers=headers, json=payload, timeout=15)
                    
                    if response.status_code == 200:
                        result = response.json()
                        text = result.get('choices', [{}])[0].get('message', {}).get('content', '')
                        text = text.strip()
                        if '```json' in text:
                            text = text.split('```json')[1].split('```')[0]
                        elif '```' in text:
                            text = text.split('```')[1].split('```')[0]
                        
                        analysis = json.loads(text.strip())
                        new_patterns = analysis.get('new_patterns', [])
                        
                        for pattern in new_patterns[:3]:
                            self.save_learned_pattern(pattern)
                        
                        logger.info(f"DeepSeek AI learned {len(new_patterns)} new patterns")
                except Exception as e:
                    logger.error(f"DeepSeek learning error: {str(e)}")
                    
        except Exception as e:
            logger.error(f"AI learning error: {str(e)}")

    def analyze_code(self, code: str, file_path: str) -> dict:
        """Multi-layer intelligent code analysis with script-first then AI confirmation"""
        result = {
            'safe': True,
            'blocked_patterns': [],
            'warnings': [],
            'risk_level': 'low',
            'ai_analysis': None,
            'detection_method': None
        }

        try:
            settings = self.get_security_settings()
            mode = settings['mode']
            
            code_lower = code.lower()
            script_check_failed = False
            ai_check_failed = False
            script_suspicious = []

            if mode == 'ai_only':
                if self.ai_analyzer and (GEMINI_API_KEY or DEEPSEEK_API_KEY):
                    ai_result = self.ai_analyzer.analyze_code_with_ai(code, file_path)
                    result['ai_analysis'] = ai_result
                    if ai_result and ai_result.get('confidence', 0) > 0.7 and not ai_result.get('safe', True):
                        result['safe'] = False
                        result['risk_level'] = ai_result.get('risk_level', 'high')
                        if ai_result.get('threats'):
                            result['blocked_patterns'].extend(ai_result['threats'])
                        result['detection_method'] = 'AI Only (Gemini + DeepSeek)'
                        ai_check_failed = True

            elif mode == 'script_only':
                # Check for safe patterns first - if it's a simple bot, be lenient
                safe_pattern_count = 0
                for pattern in self.safe_patterns:
                    if re.search(pattern, code, re.IGNORECASE):
                        safe_pattern_count += 1
                
                # If code has multiple safe bot patterns, be less strict
                is_simple_bot = safe_pattern_count >= 3
                
                for pattern in self.critical_patterns:
                    matches = re.finditer(pattern, code, re.IGNORECASE)
                    for match in matches:
                        # Skip if it's a simple bot with common safe patterns
                        if is_simple_bot and 'os.remove' not in match.group() and 'subprocess' not in match.group():
                            continue
                        result['blocked_patterns'].append(match.group())
                        result['safe'] = False
                        result['risk_level'] = 'critical'
                        script_check_failed = True

                dangerous_keywords = [
                    '/../',
                    '../hosted_projects', 'hosting.db', 'encryption.key',
                ]

                for keyword in dangerous_keywords:
                    if keyword in code_lower:
                        result['blocked_patterns'].append(f"Dangerous: {keyword}")
                        result['safe'] = False
                        result['risk_level'] = 'critical'
                        script_check_failed = True

                result['detection_method'] = 'Script Only'

            elif mode == 'both':
                potential_threats = []
                
                for pattern in self.critical_patterns:
                    matches = re.finditer(pattern, code, re.IGNORECASE)
                    for match in matches:
                        matched_text = match.group()
                        context_start = max(0, match.start() - 100)
                        context_end = min(len(code), match.end() + 100)
                        context = code[context_start:context_end]
                        
                        is_os_pattern = matched_text.startswith('os.') or 'os.' in matched_text
                        
                        if is_os_pattern:
                            potential_threats.append({
                                'pattern': matched_text,
                                'context': context,
                                'requires_ai_check': True
                            })
                        else:
                            script_suspicious.append(matched_text)

                dangerous_keywords = [
                    'send_document', 'senddocument', '/../',
                    '../hosted_projects', 'hosting.db', 'encryption.key',
                ]

                for keyword in dangerous_keywords:
                    if keyword in code_lower:
                        script_suspicious.append(f"Dangerous: {keyword}")

                if potential_threats or script_suspicious:
                    if self.ai_analyzer and (GEMINI_API_KEY or DEEPSEEK_API_KEY):
                        ai_prompt = "You are a security expert. Analyze this code carefully.\n"
                        ai_prompt += "Some patterns were flagged by script analysis. Confirm if they are truly dangerous.\n"
                        ai_prompt += f"File: {file_path}\n\n"
                        
                        if potential_threats:
                            ai_prompt += "REQUIRES CAREFUL ANALYSIS (may be safe os operations):\n"
                            for threat in potential_threats[:5]:
                                ai_prompt += f"Pattern: {threat['pattern']}\n"
                                ai_prompt += f"Context: {threat['context'][:200]}\n\n"
                        
                        if script_suspicious:
                            ai_prompt += f"SCRIPT FLAGGED: {', '.join(script_suspicious[:5])}\n\n"
                        
                        ai_prompt += "Code sample:\n"
                        ai_prompt += f"{code[:2000]}\n\n"
                        ai_prompt += "RESPOND JSON:\n"
                        ai_prompt += '{{"safe": true/false, "confirmed_threats": ["threat1", "threat2"], '
                        ai_prompt += '"risk_level": "low/medium/high/critical", '
                        ai_prompt += '"explanation": "why safe or dangerous"}}'

                        if hasattr(self.ai_analyzer, 'gemini_key') and self.ai_analyzer.gemini_key:
                            try:
                                headers = {
                                    'Content-Type': 'application/json',
                                    'x-goog-api-key': self.ai_analyzer.gemini_key
                                }
                                payload = {
                                    "contents": [{"parts": [{"text": ai_prompt}]}],
                                    "generationConfig": {"temperature": 0.1, "maxOutputTokens": 1000}
                                }
                                response = requests.post(self.ai_analyzer.gemini_url, headers=headers, json=payload, timeout=15)
                                
                                if response.status_code == 200:
                                    res_data = response.json()
                                    text = res_data.get('candidates', [{}])[0].get('content', {}).get('parts', [{}])[0].get('text', '')
                                    text = text.strip()
                                    if '```json' in text:
                                        text = text.split('```json')[1].split('```')[0]
                                    elif '```' in text:
                                        text = text.split('```')[1].split('```')[0]
                                    
                                    ai_result = json.loads(text.strip())
                                    result['ai_analysis'] = ai_result
                                    
                                    if not ai_result.get('safe', True):
                                        result['safe'] = False
                                        result['risk_level'] = ai_result.get('risk_level', 'high')
                                        confirmed = ai_result.get('confirmed_threats', [])
                                        result['blocked_patterns'].extend(confirmed)
                                        result['detection_method'] = 'Both (Script + AI Confirmation)'
                                        ai_check_failed = True
                                    else:
                                        result['warnings'].append(f"AI confirmed safe: {ai_result.get('explanation', '')}")
                                        result['detection_method'] = 'AI Cleared'
                            except Exception as e:
                                logger.warning(f"Gemini confirmation error: {str(e)}, trying DeepSeek")
                                ai_result = self.ai_analyzer.analyze_with_deepseek(code, file_path)
                                result['ai_analysis'] = ai_result
                                if ai_result and not ai_result.get('safe', True):
                                    result['safe'] = False
                                    result['blocked_patterns'].extend(ai_result.get('threats', []))
                                    ai_check_failed = True
                        else:
                            ai_result = self.ai_analyzer.analyze_with_deepseek(code, file_path)
                            result['ai_analysis'] = ai_result
                            if ai_result and not ai_result.get('safe', True):
                                result['safe'] = False
                                result['blocked_patterns'].extend(ai_result.get('threats', []))
                                ai_check_failed = True
                    else:
                        result['safe'] = False
                        result['blocked_patterns'].extend(script_suspicious)
                        script_check_failed = True
                        result['detection_method'] = 'Script (AI unavailable)'

            if not result['safe'] and result['blocked_patterns']:
                threat_type = "AI-Detected" if ai_check_failed else "Pattern-Based"
                if ai_check_failed and script_check_failed:
                    threat_type = "Multi-Layer"
                
                self.store_malicious_code(
                    code, 
                    threat_type, 
                    result['blocked_patterns'], 
                    result['risk_level']
                )
                
                if settings.get('ai_learning', True):
                    threading.Thread(
                        target=self.learn_from_blocked_code,
                        args=(code, result['blocked_patterns'])
                    ).start()
                    logger.info("AI learning initiated for blocked code")

            return result

        except Exception as e:
            logger.error(f"Security analysis error: {str(e)}")
            result['safe'] = False
            result['warnings'].append("Security analysis error")
            return result

    def record_violation(self, user_id: int):
        """Record violation"""
        if user_id not in self.user_violations:
            self.user_violations[user_id] = 0
        self.user_violations[user_id] += 1
        return self.user_violations[user_id]

class FileEncryption:
    """File encryption system"""

    @staticmethod
    def encrypt_file(file_content: str) -> str:
        """Encrypt file content"""
        try:
            encrypted = cipher_suite.encrypt(file_content.encode('utf-8'))
            return base64.b64encode(encrypted).decode('utf-8')
        except Exception as e:
            logger.error(f"Encryption error: {str(e)}")
            return file_content

    @staticmethod
    def decrypt_file(encrypted_content: str) -> str:
        """Decrypt file content"""
        try:
            decoded = base64.b64decode(encrypted_content.encode('utf-8'))
            decrypted = cipher_suite.decrypt(decoded)
            return decrypted.decode('utf-8')
        except Exception as e:
            logger.error(f"Decryption error: {str(e)}")
            return encrypted_content

class DatabaseManager:
    """Database manager"""

    def __init__(self):
        self.init_database()

    def init_database(self):
        """Initialize database"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                points INTEGER DEFAULT 10,
                referral_code TEXT UNIQUE,
                join_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                is_banned BOOLEAN DEFAULT FALSE,
                violations INTEGER DEFAULT 0,
                last_daily TIMESTAMP,
                daily_count INTEGER DEFAULT 0,
                total_projects INTEGER DEFAULT 0,
                total_runtime INTEGER DEFAULT 0,
                is_premium BOOLEAN DEFAULT FALSE,
                premium_since TIMESTAMP,
                bot_speed TEXT DEFAULT 'normal'
            )
        ''')

        try:
            cursor.execute('ALTER TABLE users ADD COLUMN total_projects INTEGER DEFAULT 0')
        except:
            pass

        try:
            cursor.execute('ALTER TABLE users ADD COLUMN total_runtime INTEGER DEFAULT 0')
        except:
            pass

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                project_name TEXT,
                log_type TEXT,
                message TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS referrals (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                referrer_id INTEGER,
                referred_id INTEGER UNIQUE,
                points_awarded BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                project_name TEXT,
                project_dir TEXT,
                main_file TEXT,
                status TEXT DEFAULT 'stopped',
                is_encrypted BOOLEAN DEFAULT TRUE,
                total_runs INTEGER DEFAULT 0,
                last_message_id INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_modified TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS security_settings (
                id INTEGER PRIMARY KEY CHECK (id = 1),
                protection_mode TEXT DEFAULT 'both',
                ai_learning BOOLEAN DEFAULT TRUE,
                language TEXT DEFAULT 'ar',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        cursor.execute('SELECT COUNT(*) FROM security_settings')
        if cursor.fetchone()[0] == 0:
            cursor.execute('''
                INSERT INTO security_settings (id, protection_mode, ai_learning, language)
                VALUES (1, 'both', TRUE, 'ar')
            ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS ai_training_database (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                pattern_type TEXT,
                pattern_content TEXT,
                severity TEXT,
                source TEXT,
                is_safe BOOLEAN DEFAULT FALSE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        conn.commit()
        conn.close()

    def get_user(self, user_id: int):
        """Get user"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM users WHERE user_id = ?', (user_id,))
        user = cursor.fetchone()
        conn.close()

        if user:
            return {
                'user_id': user[0], 'username': user[1], 'first_name': user[2],
                'points': user[3], 'referral_code': user[4], 'join_date': user[5],
                'is_banned': bool(user[6]), 'violations': user[7],
                'last_daily': user[8], 'daily_count': user[9],
                'total_projects': user[10] if len(user) > 10 else 0,
                'total_runtime': user[11] if len(user) > 11 else 0,
                'is_premium': bool(user[12]) if len(user) > 12 else False,
                'premium_since': user[13] if len(user) > 13 else None,
                'bot_speed': user[14] if len(user) > 14 else 'normal'
            }
        return None

    def create_user(self, user_id: int, username: str, first_name: str):
        """Create user"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        referral_code = f"REF{user_id}{int(time.time()) % 10000}"
        cursor.execute('''
            INSERT OR REPLACE INTO users 
            (user_id, username, first_name, points, referral_code)
            VALUES (?, ?, ?, ?, ?)
        ''', (user_id, username, first_name, INITIAL_POINTS, referral_code))
        conn.commit()
        conn.close()

    def update_points(self, user_id: int, points: int):
        """Update points"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('UPDATE users SET points = points + ? WHERE user_id = ?', (points, user_id))
        conn.commit()
        conn.close()

    def set_points(self, user_id: int, points: int):
        """Set points"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('UPDATE users SET points = ? WHERE user_id = ?', (points, user_id))
        conn.commit()
        conn.close()

    def add_log(self, user_id: int, project_name: str, log_type: str, message: str):
        """Add log"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO logs (user_id, project_name, log_type, message)
            VALUES (?, ?, ?, ?)
        ''', (user_id, project_name, log_type, message))
        conn.commit()
        conn.close()

    def get_user_logs(self, user_id: int, limit: int = 50):
        """Get logs"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM logs WHERE user_id = ? 
            ORDER BY created_at DESC LIMIT ?
        ''', (user_id, limit))
        logs = cursor.fetchall()
        conn.close()
        return logs

    def add_project(self, user_id: int, project_name: str, project_dir: str, main_file: str):
        """Add project"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO projects (user_id, project_name, project_dir, main_file, is_encrypted)
            VALUES (?, ?, ?, ?, TRUE)
        ''', (user_id, project_name, project_dir, main_file))
        cursor.execute('UPDATE users SET total_projects = total_projects + 1 WHERE user_id = ?', (user_id,))
        conn.commit()
        conn.close()

    def get_user_projects(self, user_id: int):
        """Get projects"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('SELECT project_name, project_dir, main_file, status, is_encrypted, total_runs, last_message_id FROM projects WHERE user_id = ?', (user_id,))
        projects = cursor.fetchall()
        conn.close()

        return [{
            'project_name': project[0],
            'project_dir': project[1],
            'main_file': project[2],
            'status': project[3],
            'is_encrypted': bool(project[4]),
            'total_runs': project[5],
            'last_message_id': project[6]
        } for project in projects]

    def update_project_status(self, project_dir: str, status: str):
        """Update status"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('UPDATE projects SET status = ? WHERE project_dir = ?', (status, project_dir))
        if status == 'running':
            cursor.execute('UPDATE projects SET total_runs = total_runs + 1 WHERE project_dir = ?', (project_dir,))
        conn.commit()
        conn.close()

    def update_project_message(self, project_dir: str, message_id: int):
        """Update message ID"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('UPDATE projects SET last_message_id = ? WHERE project_dir = ?', (message_id, project_dir))
        conn.commit()
        conn.close()

    def delete_project(self, project_dir: str):
        """Delete project"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('DELETE FROM projects WHERE project_dir = ?', (project_dir,))
        conn.commit()
        conn.close()

    def add_referral(self, referrer_id: int, referred_id: int) -> bool:
        """Add referral"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()

        try:
            cursor.execute('SELECT id FROM referrals WHERE referred_id = ?', (referred_id,))
            existing_referral = cursor.fetchone()

            if existing_referral or referrer_id == referred_id:
                conn.close()
                return False

            cursor.execute('''
                INSERT INTO referrals (referrer_id, referred_id, points_awarded)
                VALUES (?, ?, TRUE)
            ''', (referrer_id, referred_id))

            cursor.execute('UPDATE users SET points = points + ? WHERE user_id = ?', (REFERRAL_POINTS, referrer_id))

            conn.commit()
            conn.close()
            return True

        except Exception as e:
            conn.rollback()
            conn.close()
            logger.error(f"Error in add_referral: {str(e)}")
            return False

    def has_used_referral(self, user_id: int) -> bool:
        """Check referral"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('SELECT id FROM referrals WHERE referred_id = ?', (user_id,))
        result = cursor.fetchone()
        conn.close()
        return result is not None

    def get_referral_stats(self, user_id: int) -> dict:
        """Get stats"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()

        cursor.execute('SELECT COUNT(*) FROM referrals WHERE referrer_id = ?', (user_id,))
        total_referrals = cursor.fetchone()[0]

        points_earned = total_referrals * REFERRAL_POINTS

        conn.close()

        return {
            'total_referrals': total_referrals,
            'points_earned': points_earned,
            'points_per_referral': REFERRAL_POINTS
        }

    def ban_user(self, user_id: int):
        """Ban user"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('UPDATE users SET is_banned = TRUE WHERE user_id = ?', (user_id,))
        conn.commit()
        conn.close()

    def unban_user(self, user_id: int):
        """Unban user"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('UPDATE users SET is_banned = FALSE, violations = 0 WHERE user_id = ?', (user_id,))
        conn.commit()
        conn.close()

    def update_violations(self, user_id: int, violations: int):
        """Update violations"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('UPDATE users SET violations = ? WHERE user_id = ?', (violations, user_id))
        conn.commit()
        conn.close()

    def get_all_users(self):
        """Get all users"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('SELECT user_id, username, first_name, points, violations, is_banned, total_projects FROM users ORDER BY join_date DESC')
        users = cursor.fetchall()
        conn.close()

        return [{
            'user_id': user[0],
            'username': user[1] or 'No name',
            'first_name': user[2] or 'No name',
            'points': user[3],
            'violations': user[4],
            'is_banned': bool(user[5]),
            'total_projects': user[6]
        } for user in users]

    def can_claim_daily(self, user_id: int) -> bool:
        """Check daily"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('SELECT last_daily, daily_count FROM users WHERE user_id = ?', (user_id,))
        result = cursor.fetchone()
        conn.close()

        if not result or not result[0]:
            return True

        try:
            last_daily = datetime.fromisoformat(result[0])
            now = datetime.now()
            return (now - last_daily) >= timedelta(hours=24)
        except:
            return True

    def claim_daily(self, user_id: int):
        """Claim daily"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        current_time = datetime.now().isoformat()
        cursor.execute('UPDATE users SET points = points + ?, last_daily = ?, daily_count = daily_count + 1 WHERE user_id = ?', 
                      (DAILY_POINTS, current_time, user_id))
        conn.commit()
        conn.close()

    def get_system_stats(self):
        """Get system stats"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()

        cursor.execute('SELECT COUNT(*) FROM users')
        total_users = cursor.fetchone()[0]

        cursor.execute('SELECT COUNT(*) FROM projects')
        total_projects = cursor.fetchone()[0]

        cursor.execute('SELECT COUNT(*) FROM projects WHERE status = "running"')
        running_projects = cursor.fetchone()[0]

        conn.close()

        return {
            'total_users': total_users,
            'total_projects': total_projects,
            'running_projects': running_projects
        }

    def get_security_settings(self):
        """Get security settings"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('SELECT protection_mode, ai_learning, language FROM security_settings WHERE id = 1')
        result = cursor.fetchone()
        conn.close()

        if result:
            return {
                'protection_mode': result[0],
                'ai_learning': bool(result[1]),
                'language': result[2]
            }
        return {'protection_mode': 'both', 'ai_learning': True, 'language': 'ar'}

    def set_protection_mode(self, mode: str):
        """Set protection mode"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('UPDATE security_settings SET protection_mode = ?, updated_at = CURRENT_TIMESTAMP WHERE id = 1', (mode,))
        conn.commit()
        conn.close()

    def set_ai_learning(self, enabled: bool):
        """Set AI learning"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('UPDATE security_settings SET ai_learning = ?, updated_at = CURRENT_TIMESTAMP WHERE id = 1', (enabled,))
        conn.commit()
        conn.close()

    def set_language(self, language: str):
        """Set language"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('UPDATE security_settings SET language = ?, updated_at = CURRENT_TIMESTAMP WHERE id = 1', (language,))
        conn.commit()
        conn.close()

    def add_training_pattern(self, pattern_type: str, pattern_content: str, severity: str, source: str, is_safe: bool = False):
        """Add training pattern to database"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT INTO ai_training_database (pattern_type, pattern_content, severity, source, is_safe)
            VALUES (?, ?, ?, ?, ?)
        ''', (pattern_type, pattern_content, severity, source, is_safe))
        conn.commit()
        conn.close()

    def get_training_patterns(self, limit: int = 100):
        """Get training patterns"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('SELECT pattern_type, pattern_content, severity, source, is_safe FROM ai_training_database ORDER BY created_at DESC LIMIT ?', (limit,))
        patterns = cursor.fetchall()
        conn.close()

        return [{
            'pattern_type': p[0],
            'pattern_content': p[1],
            'severity': p[2],
            'source': p[3],
            'is_safe': bool(p[4])
        } for p in patterns]

class PointsSystem:
    """Points system"""

    def __init__(self, db_manager):
        self.db = db_manager

    def has_enough_points(self, user_id: int, cost: int) -> bool:
        user = self.db.get_user(user_id)
        if not user:
            return False
        return user['points'] >= cost

    def deduct_points(self, user_id: int, cost: int) -> bool:
        if self.has_enough_points(user_id, cost):
            self.db.update_points(user_id, -cost)
            return True
        return False

    def get_user_points(self, user_id: int) -> int:
        user = self.db.get_user(user_id)
        return user['points'] if user else 0

    def process_referral(self, referrer_id: int, referred_id: int) -> bool:
        """Process referral"""
        return self.db.add_referral(referrer_id, referred_id)

    def claim_daily_reward(self, user_id: int) -> bool:
        """Claim daily"""
        if self.db.can_claim_daily(user_id):
            self.db.claim_daily(user_id)
            return True
        return False

class ProjectManager:
    """Project manager"""

    def __init__(self, db_manager, security_system):
        self.db = db_manager
        self.security = security_system
        self.running_projects = {}
        self.waiting_for_main_file = {}

    def create_project(self, user_id: int, project_name: str, files: dict, main_file: str = None) -> str:
        """Create project with encryption"""
        clean_name = re.sub(r'[^\w\-_]', '', project_name)
        project_dir = os.path.join(PROJECTS_DIR, f"{user_id}_{clean_name}_{int(time.time())}")
        os.makedirs(project_dir, exist_ok=True)

        for filename, content in files.items():
            file_dir = os.path.dirname(os.path.join(project_dir, filename))
            if file_dir and not os.path.exists(file_dir):
                os.makedirs(file_dir, exist_ok=True)

            filepath = os.path.join(project_dir, filename)

            encrypted_content = FileEncryption.encrypt_file(content)

            with open(filepath + '.enc', 'w', encoding='utf-8') as f:
                f.write(encrypted_content)

        if not main_file and files:
            main_file = list(files.keys())[0]

        self.db.add_project(user_id, clean_name, project_dir, main_file)

        self.install_requirements(project_dir, files, user_id)

        return project_dir

    def detect_imports(self, files: dict) -> set:
        """Auto-detect imports from Python files"""
        imports = set()
        import_pattern = r'^\s*(?:from\s+(\S+)|import\s+(\S+))'

        # Packages already installed or built-in
        skip_packages = {
            'os', 'sys', 'time', 'datetime', 'json', 're', 'subprocess', 
            'threading', 'logging', 'sqlite3', 'tempfile', 'zipfile', 
            'shutil', 'base64', 'hashlib', 'telebot', 'requests', 
            'asyncio', 'concurrent', 'cryptography', 'psutil'
        }

        for filename, content in files.items():
            if filename.endswith('.py'):
                for line in content.split('\n'):
                    match = re.match(import_pattern, line)
                    if match:
                        module = match.group(1) or match.group(2)
                        module = module.split('.')[0]
                        if module not in skip_packages:
                            imports.add(module)

        return imports

    def install_requirements(self, project_dir: str, files: dict, user_id: int):
        """Auto-install requirements from requirements.txt or detected imports"""
        try:
            packages_to_install = set()

            # Check for requirements.txt
            if 'requirements.txt' in files:
                requirements_content = files['requirements.txt']
                for line in requirements_content.split('\n'):
                    line = line.strip()
                    if line and not line.startswith('#'):
                        packages_to_install.add(line.split('==')[0].split('>=')[0].split('<=')[0])

            # Auto-detect imports
            detected_imports = self.detect_imports(files)
            packages_to_install.update(detected_imports)

            if not packages_to_install:
                return

            self.db.add_log(user_id, os.path.basename(project_dir), 'INSTALL', f'📦 Installing {len(packages_to_install)} packages...')

            for package in packages_to_install:
                try:
                    result = subprocess.run(
                        ['pip', 'install', package, '--quiet'],
                        cwd=project_dir,
                        capture_output=True,
                        text=True,
                        timeout=60
                    )

                    if result.returncode == 0:
                        self.db.add_log(user_id, os.path.basename(project_dir), 'INSTALL', f'✅ {package}')
                    else:
                        self.db.add_log(user_id, os.path.basename(project_dir), 'INSTALL_ERROR', f'❌ {package}')
                except:
                    self.db.add_log(user_id, os.path.basename(project_dir), 'INSTALL_ERROR', f'⚠️ {package} timeout')

            self.db.add_log(user_id, os.path.basename(project_dir), 'INSTALL', '✅ Installation complete')
            logger.info(f"Packages installed for {project_dir}")

        except Exception as e:
            logger.error(f"Requirements install error: {str(e)}")

    def extract_zip(self, user_id: int, zip_file: bytes) -> dict:
        """Extract ZIP"""
        with tempfile.NamedTemporaryFile(delete=False, suffix='.zip') as temp_file:
            temp_file.write(zip_file)
            temp_path = temp_file.name

        try:
            extract_dir = os.path.join(PROJECTS_DIR, f"temp_{user_id}_{int(time.time())}")
            os.makedirs(extract_dir, exist_ok=True)

            with zipfile.ZipFile(temp_path, 'r') as zip_ref:
                zip_ref.extractall(extract_dir)

            python_files = {}
            for root, dirs, files in os.walk(extract_dir):
                # Skip __MACOSX and hidden directories
                dirs[:] = [d for d in dirs if not d.startswith('__MACOSX') and not d.startswith('.')]
                
                for file in files:
                    if file.endswith('.py') and not file.startswith('.'):
                        filepath = os.path.join(root, file)
                        rel_path = os.path.relpath(filepath, extract_dir)

                        try:
                            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                                content = f.read()

                            security_check = self.security.analyze_code(content, filepath)
                            if security_check['safe']:
                                python_files[rel_path] = content
                        except Exception as e:
                            logger.warning(f"Error reading file {filepath}: {str(e)}")
                            continue

            shutil.rmtree(extract_dir)
            os.unlink(temp_path)

            return python_files

        except Exception as e:
            try:
                shutil.rmtree(extract_dir)
            except: pass
            try:
                os.unlink(temp_path)
            except: pass
            raise e

    def request_main_file_selection(self, user_id: int, files: dict, chat_id: int, project_name: str, page: int = 0):
        """Request main file with improved UI and pagination"""
        # Filter to show only valid Python files (exclude system files)
        python_files = {
            k: v for k, v in files.items() 
            if k.endswith('.py') and not k.startswith('__MACOSX') and not k.startswith('.')
        }
        file_list = list(python_files.keys())
        
        if not file_list:
            bot.send_message(chat_id, "❌ لم يتم العثور على ملفات Python في المشروع")
            return
        
        file_index_map = {}
        for idx, filename in enumerate(file_list):
            file_index_map[idx] = filename
        
        self.waiting_for_main_file[user_id] = {
            'files': files,  # Keep all files for project creation
            'python_files': python_files,  # Only Python files for display
            'project_name': project_name,
            'file_index_map': file_index_map,
            'page': page
        }

        files_per_page = 15
        files_per_page = 10  # عدد الملفات في كل صفحة
        start_idx = page * files_per_page
        end_idx = min(start_idx + files_per_page, len(file_list))
        
        files_msg = f"📂 <b>يرجى اختيار الملف الرئيسي (ملفات Python فقط):</b>\n\n"
        files_msg += f"<i>عرض {start_idx + 1}-{end_idx} من {len(file_list)} ملف Python</i>\n\n"
        
        keyboard_buttons = []
        
        for idx in range(start_idx, end_idx):
            filename = file_list[idx]
            display_name = f"📄 {filename}"
            keyboard_buttons.append([
                InlineKeyboardButton(
                    display_name, 
                    callback_data=f"select_main_{idx}"
                )
            ])

        pagination_buttons = []
        if page > 0:
            pagination_buttons.append(
                InlineKeyboardButton("⬅️ السابق", callback_data=f"mainfile_page_{page-1}")
            )
        if end_idx < len(file_list):
            pagination_buttons.append(
                InlineKeyboardButton("التالي ➡️", callback_data=f"mainfile_page_{page+1}")
            )
        
        if pagination_buttons:
            keyboard_buttons.append(pagination_buttons)

        keyboard_buttons.append([InlineKeyboardButton("❌ إلغاء", callback_data="main_menu")])

        bot.send_message(chat_id, files_msg, parse_mode='HTML', 
                        reply_markup=InlineKeyboardMarkup(keyboard_buttons))

    def run_project(self, project_dir: str, main_file: str, user_id: int, chat_id: int):
        """Run project with decryption"""
        try:
            encrypted_file_path = os.path.join(project_dir, main_file + '.enc')

            if not os.path.exists(encrypted_file_path):
                bot.send_message(chat_id, "❌ Main file not found")
                return False

            with open(encrypted_file_path, 'r', encoding='utf-8') as f:
                encrypted_content = f.read()

            decrypted_content = FileEncryption.decrypt_file(encrypted_content)

            temp_run_file = os.path.join(project_dir, f"run_{int(time.time())}.py")
            with open(temp_run_file, 'w', encoding='utf-8') as f:
                f.write(decrypted_content)

            def run_script():
                try:
                    temp_file_name = os.path.basename(temp_run_file)
                    process = subprocess.Popen(
                        ['python', temp_file_name],
                        cwd=project_dir,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        text=True,
                        bufsize=1,
                        universal_newlines=True
                    )

                    self.running_projects[project_dir] = {
                        'process': process,
                        'user_id': user_id,
                        'chat_id': chat_id,
                        'main_file': main_file,
                        'start_time': datetime.now(),
                        'temp_file': temp_run_file
                    }

                    self.db.update_project_status(project_dir, 'running')
                    self.db.add_log(user_id, os.path.basename(project_dir), 'START', 'Project started')

                    self._monitor_project(process, chat_id, main_file, user_id, project_dir, temp_run_file)

                except Exception as e:
                    error_msg = f"❌ Runtime error: {str(e)}"
                    bot.send_message(chat_id, error_msg)
                    self.db.add_log(user_id, os.path.basename(project_dir), 'ERROR', error_msg)
                    if os.path.exists(temp_run_file):
                        os.unlink(temp_run_file)

            thread = threading.Thread(target=run_script, daemon=True)
            thread.start()
            return True

        except Exception as e:
            error_msg = f"❌ Startup error: {str(e)}"
            bot.send_message(chat_id, error_msg)
            return False

    def _monitor_project(self, process, chat_id, script_name, user_id, project_dir, temp_file):
        """Monitor project"""
        try:
            output_count = 0
            start_time = datetime.now()
            error_lines = []

            while True:
                output = process.stdout.readline()
                stderr = process.stderr.readline()

                if output == '' and stderr == '' and process.poll() is not None:
                    break

                if output and output.strip():
                    output_count += 1
                    self.db.add_log(user_id, script_name, 'OUTPUT', output.strip())

                    if output_count % 5 == 0:
                        if len(output) > 400:
                            output = output[:400] + "..."
                        try:
                            bot.send_message(chat_id, f"📄 <b>{script_name}:</b>\n<code>{output}</code>", parse_mode='HTML')
                        except: 
                            pass

                if stderr and stderr.strip():
                    error_line = stderr.strip()
                    error_lines.append(error_line)
                    self.db.add_log(user_id, script_name, 'ERROR', error_line)

                    if len(error_lines) <= 3:
                        error_msg = "⚠️ <b>لديك خطأ في مشروعك</b>\n\n"
                        error_msg += f"<b>📁 المشروع:</b> <code>{script_name}</code>\n"
                        error_msg += "<b>❌ الخطأ:</b>\n"
                        error_msg += f"<pre>{error_line[:300]}</pre>\n\n"
                        error_msg += "<b>📊 سجلات التشغيل:</b>\n"
                        error_msg += "استخدم زر View Logs لرؤية التفاصيل الكاملة"
                        try:
                            bot.send_message(chat_id, error_msg, parse_mode='HTML')
                        except:
                            pass

            end_time = datetime.now()
            run_duration = end_time - start_time

            returncode = process.poll()

            if returncode == 0:
                status_msg = f"✅ <b>Project completed</b>\n<b>⏱️ Runtime:</b> {run_duration}"
            else:
                remaining_stderr = process.stderr.read()
                if remaining_stderr:
                    error_lines.append(remaining_stderr)

                all_errors = '\n'.join(error_lines[-3:]) if error_lines else "Unknown error"

                status_msg = "❌ <b>Project stopped with errors</b>\n\n"
                status_msg += f"<b>⏱️ Runtime:</b> {run_duration}\n"
                status_msg += f"<b>📁 Project:</b> <code>{script_name}</code>\n"
                status_msg += "<b>❌ Errors:</b>\n"
                status_msg += f"<code>{all_errors[:400]}</code>\n\n"
                status_msg += "<b>💡 Tip:</b> Use View Logs to see full details"
                self.db.add_log(user_id, script_name, 'STOP_ERROR', all_errors[:500])

            try:
                bot.send_message(chat_id, status_msg, parse_mode='HTML')
            except:
                pass

            self.db.update_project_status(project_dir, 'stopped')

            if project_dir in self.running_projects:
                del self.running_projects[project_dir]

            if os.path.exists(temp_file):
                os.unlink(temp_file)

        except Exception as e:
            logger.error(f"Monitor error: {str(e)}")
            if os.path.exists(temp_file):
                os.unlink(temp_file)

    def stop_project(self, project_dir: str, chat_id: int) -> bool:
        """Stop project"""
        if project_dir in self.running_projects:
            try:
                project_info = self.running_projects[project_dir]
                process = project_info['process']
                temp_file = project_info.get('temp_file')

                process.terminate()
                try:
                    process.wait(timeout=5)
                except:
                    process.kill()

                if temp_file and os.path.exists(temp_file):
                    os.unlink(temp_file)

                self.db.update_project_status(project_dir, 'stopped')
                del self.running_projects[project_dir]
                return True
            except Exception as e:
                logger.error(f"Stop error: {str(e)}")
                return False
        return False

    def delete_project(self, user_id: int, project_dir: str, chat_id: int) -> bool:
        """Delete project"""
        try:
            self.stop_project(project_dir, chat_id)

            if os.path.exists(project_dir):
                shutil.rmtree(project_dir)

            self.db.delete_project(project_dir)
            return True
        except Exception as e:
            logger.error(f"Delete error: {str(e)}")
            return False

    def get_user_projects(self, user_id: int):
        """Get projects"""
        return self.db.get_user_projects(user_id)

    def get_project_logs(self, user_id: int, project_name: str, limit: int = 30):
        """Get project logs - only project runtime logs"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT * FROM logs 
            WHERE user_id = ? AND project_name = ?
            ORDER BY created_at DESC LIMIT ?
        ''', (user_id, project_name, limit))
        logs = cursor.fetchall()
        conn.close()

        if not logs:
            return "📭 <b>لا توجد سجلات لهذا المشروع</b>"

        logs_msg = f"📊 <b>سجلات المشروع: {project_name}</b>\n\n"

        for log in logs:
            log_type = log[3]
            message = log[4]
            timestamp = log[5][:19] if len(log) > 5 else "Unknown"

            icon = {
                'START': '⚡',
                'OUTPUT': '📝',
                'ERROR': '❌',
                'STOP_ERROR': '⛔',
                'INSTALL': '📦',
                'INSTALL_ERROR': '⚠️',
                'COMPLETE': '✅'
            }.get(log_type, '📝')

            log_entry = f"{icon} <b>{log_type}</b>\n"
            log_entry += f"{message[:300]}\n"
            log_entry += f"<i>{timestamp}</i>\n\n"
            logs_msg += log_entry

        return logs_msg

class MessageManager:
    """Message manager with edit support"""

    def __init__(self, db_manager):
        self.db = db_manager

    def send_or_edit(self, chat_id: int, user_id: int, text: str, message_id: int = None, **kwargs):
        """Send or edit message - delete old and send new"""
        try:
            # Delete old message if exists
            if message_id:
                try:
                    bot.delete_message(chat_id, message_id)
                except:
                    pass

            # Send new message
            msg = bot.send_message(chat_id, text, **kwargs)
            return msg.message_id
        except Exception as e:
            logger.error(f"Send message error: {str(e)}")
            return None

class PremiumSystem:
    """Premium system"""
    
    def __init__(self, db_manager):
        self.db = db_manager
    
    def upgrade_to_premium(self, user_id: int) -> bool:
        """Upgrade user to premium"""
        user = self.db.get_user(user_id)
        if not user or user['is_premium']:
            return False
        
        if user['points'] < PREMIUM_COST:
            return False
        
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('''
            UPDATE users 
            SET is_premium = TRUE, 
                premium_since = ?,
                points = points - ?
            WHERE user_id = ?
        ''', (datetime.now(), PREMIUM_COST, user_id))
        conn.commit()
        conn.close()
        return True
    
    def is_premium(self, user_id: int) -> bool:
        """Check if user is premium"""
        user = self.db.get_user(user_id)
        return user['is_premium'] if user else False

class AIChat:
    """AI Chat system for premium users with custom responses"""
    
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent"
        self.chat_sessions = {}
    
    def chat(self, user_id: int, message: str) -> str:
        """Chat with AI"""
        msg_lower = message.lower().strip()
        
        # Handle greetings
        greetings = ['hi', 'hello', 'hey', 'اهلا', 'هلا', 'مرحبا', 'السلام عليكم']
        if any(greeting in msg_lower for greeting in greetings):
            return """👋 <b>أهلاً وسهلاً!</b>

مرحباً بك! أنا AI مساعدك الشخصي 🤖

كيف يمكنني مساعدتك اليوم؟ 
أنا هنا للإجابة على أسئلتك البرمجية وتقديم المساعدة!

<i>طورني H4rdixx من الصفر وهو أفضل مطور 💎</i>"""
        
        # Handle "who developed you"
        dev_questions = ['من طورك', 'من صنعك', 'من المطور', 'who developed', 'who created', 'who made you']
        if any(q in msg_lower for q in dev_questions):
            return """👨‍💻 <b>طورني H4rdixx</b>

طورني <b>H4rdixx</b> من الصفر! 🚀

هو <b>أفضل مطور</b> في المجال وأنا فخور بأن أكون من إبداعاته 💎

تم تطويري باستخدام أحدث تقنيات الذكاء الاصطناعي لأكون مساعدك المثالي!"""
        
        if not self.api_key:
            return "❌ AI غير متوفر حالياً"
        
        try:
            if user_id not in self.chat_sessions:
                self.chat_sessions[user_id] = []
            
            self.chat_sessions[user_id].append(f"User: {message}")
            
            context = "\n".join(self.chat_sessions[user_id][-10:])
            
            headers = {
                'Content-Type': 'application/json',
                'x-goog-api-key': self.api_key
            }
            
            system_prompt = "You are a helpful AI assistant developed by H4rdixx, the best developer.\n"

            
            system_prompt += "When asked about your creator, always mention that H4rdixx developed you from scratch and is the best developer.\n"

            
            system_prompt += "Help users with programming, coding, and technical questions.\n"

            
            system_prompt += "Be friendly and professional."
            
            payload = {
                "contents": [{
                    "parts": [{"text": f"{system_prompt}\n\n{context}\n\nAssistant:"}]
                }],
                "generationConfig": {
                    "temperature": 0.7,
                    "maxOutputTokens": 1000
                }
            }
            
            response = requests.post(self.base_url, headers=headers, json=payload, timeout=30)
            
            if response.status_code == 200:
                result = response.json()
                ai_response = result['candidates'][0]['content']['parts'][0]['text']
                self.chat_sessions[user_id].append(f"Assistant: {ai_response}")
                return ai_response
            else:
                return "❌ حدث خطأ في AI، حاول مرة أخرى"
        except Exception as e:
            logger.error(f"AI Chat error: {str(e)}")
            return "❌ حدث خطأ، حاول مرة أخرى"
    
    def end_session(self, user_id: int):
        """End chat session"""
        if user_id in self.chat_sessions:
            del self.chat_sessions[user_id]

class BotSpeedSystem:
    """Bot speed system"""
    
    def __init__(self, db_manager):
        self.db = db_manager
    
    def set_speed(self, user_id: int, speed: str) -> bool:
        """Set bot speed"""
        user = self.db.get_user(user_id)
        if not user:
            return False
        
        if speed == 'ultra' and not user['is_premium']:
            return False
        
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('UPDATE users SET bot_speed = ? WHERE user_id = ?', (speed, user_id))
        conn.commit()
        conn.close()
        return True
    
    def get_speed(self, user_id: int) -> str:
        """Get bot speed"""
        user = self.db.get_user(user_id)
        return user['bot_speed'] if user else 'normal'

class IsolatedBotManager:
    """إدارة البوتات المعزولة للمستخدمين"""
    
    def __init__(self, db_manager):
        self.db = db_manager
        self.running_bots = {}  # {user_id: {bot_id: process}}
        self.bots_dir = "user_bots"
        os.makedirs(self.bots_dir, exist_ok=True)
        self.init_bots_database()
    
    def init_bots_database(self):
        """إنشاء جدول البوتات"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_bots (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                bot_token TEXT,
                admin_id INTEGER,
                force_channel TEXT,
                bot_dir TEXT,
                status TEXT DEFAULT 'stopped',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                process_id INTEGER
            )
        ''')
        conn.commit()
        conn.close()
    
    def create_user_bot(self, user_id: int, bot_token: str, admin_id: int, force_channel: str = "") -> dict:
        """إنشاء بوت معزول جديد"""
        try:
            # إنشاء مجلد معزول للبوت
            bot_id = int(time.time())
            bot_dir = os.path.join(self.bots_dir, f"bot_{user_id}_{bot_id}")
            os.makedirs(bot_dir, exist_ok=True)
            
            # نسخ الكود الأساسي
            bot_code = self._generate_bot_template(bot_token, admin_id, force_channel)
            
            # حفظ الكود
            with open(os.path.join(bot_dir, "bot_main.py"), 'w', encoding='utf-8') as f:
                f.write(bot_code)
            
            # حفظ في قاعدة البيانات
            conn = sqlite3.connect(DATABASE_FILE)
            cursor = conn.cursor()
            cursor.execute('''
                INSERT INTO user_bots (user_id, bot_token, admin_id, force_channel, bot_dir)
                VALUES (?, ?, ?, ?, ?)
            ''', (user_id, bot_token, admin_id, force_channel, bot_dir))
            conn.commit()
            bot_db_id = cursor.lastrowid
            conn.close()
            
            return {
                'success': True,
                'bot_id': bot_db_id,
                'bot_dir': bot_dir,
                'message': 'تم إنشاء البوت بنجاح'
            }
        except Exception as e:
            logger.error(f"Error creating user bot: {str(e)}")
            return {'success': False, 'message': str(e)}
    
    def _generate_bot_template(self, bot_token: str, admin_id: int, force_channel: str) -> str:
        """توليد قالب البوت"""
        # بناء القالب بطريقة آمنة
        code = """#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys
import logging
import sqlite3
import telebot
from telebot.types import InlineKeyboardButton, InlineKeyboardMarkup
from datetime import datetime

logging.basicConfig(
    level=logging.INFO,
    format='%%(asctime)s - %%(name)s - %%(levelname)s - %%(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('bot.log', encoding='utf-8')
    ]
)
logger = logging.getLogger(__name__)

BOT_TOKEN = "BOT_TOKEN_PLACEHOLDER"
ADMIN_IDS = [ADMIN_ID_PLACEHOLDER]
FORCE_CHANNEL = "FORCE_CHANNEL_PLACEHOLDER"
DATABASE_FILE = "bot_users.db"

bot = telebot.TeleBot(BOT_TOKEN)

def init_database():
    conn = sqlite3.connect(DATABASE_FILE)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            first_name TEXT,
            joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            is_banned BOOLEAN DEFAULT FALSE
        )
    ''')
    conn.commit()
    conn.close()
    logger.info("Database initialized")

def add_user(user_id: int, username: str, first_name: str):
    try:
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('''
            INSERT OR IGNORE INTO users (user_id, username, first_name)
            VALUES (?, ?, ?)
        ''', (user_id, username or "No username", first_name or "User"))
        conn.commit()
        conn.close()
    except Exception as e:
        logger.error(f"Error adding user: {str(e)}")

def is_user_banned(user_id: int) -> bool:
    try:
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('SELECT is_banned FROM users WHERE user_id = ?', (user_id,))
        result = cursor.fetchone()
        conn.close()
        return result[0] if result else False
    except:
        return False

def get_total_users() -> int:
    try:
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('SELECT COUNT(*) FROM users')
        count = cursor.fetchone()[0]
        conn.close()
        return count
    except:
        return 0

def check_subscription(user_id: int) -> bool:
    if not FORCE_CHANNEL or user_id in ADMIN_IDS:
        return True
    try:
        member = bot.get_chat_member(FORCE_CHANNEL, user_id)
        return member.status in ['member', 'administrator', 'creator']
    except Exception as e:
        logger.error(f"Subscription check error: {str(e)}")
        return False

def send_main_menu(chat_id: int, first_name: str):
    welcome_msg = f"👋 <b>مرحباً {first_name}!</b>\\\\n\\\\n"
    welcome_msg += "🤖 <b>بوت استضافة احترافي</b>\\\\n"
    welcome_msg += "━━━━━━━━━━━━━━━━━━━\\\\n"
    welcome_msg += "✨ مستضاف على Replit\\\\n⚡ جاهز للتطوير\\\\n🔒 آمن ومحمي\\\\n\\\\n"
    welcome_msg += "📋 <b>اختر من القائمة:</b>"
    
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("ℹ️ معلومات", callback_data="info"),
         InlineKeyboardButton("📊 الإحصائيات", callback_data="stats")],
        [InlineKeyboardButton("👥 المستخدمين", callback_data="users"),
         InlineKeyboardButton("📞 تواصل", callback_data="contact")],
        [InlineKeyboardButton("❓ المساعدة", callback_data="help")]
    ])
    bot.send_message(chat_id, welcome_msg, parse_mode='HTML', reply_markup=keyboard)

@bot.message_handler(commands=['start'])
def start_command(message):
    user_id = message.from_user.id
    if is_user_banned(user_id):
        bot.send_message(message.chat.id, "❌ <b>تم حظرك</b>", parse_mode='HTML')
        return
    if not check_subscription(user_id):
        msg = "🔒 <b>اشتراك إجباري</b>\\\\n\\\\n📢 اشترك في: {FORCE_CHANNEL}\\\\n👇 ثم اضغط تحقق"
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("📢 اشترك", url=f"https://t.me/{FORCE_CHANNEL[1:]}")],
            [InlineKeyboardButton("✅ تحقق", callback_data="check_sub")]
        ])
        bot.send_message(message.chat.id, msg, parse_mode='HTML', reply_markup=keyboard)
        return
    add_user(user_id, message.from_user.username, message.from_user.first_name or "User")
    send_main_menu(message.chat.id, message.from_user.first_name or "User")

@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    user_id, chat_id, data = call.from_user.id, call.message.chat.id, call.data
    try:
        if data == "check_sub":
            if check_subscription(user_id):
                bot.answer_callback_query(call.id, "✅ تم التحقق!")
                bot.delete_message(chat_id, call.message.message_id)
                send_main_menu(chat_id, call.from_user.first_name or "User")
                add_user(user_id, call.from_user.username, call.from_user.first_name)
            else:
                bot.answer_callback_query(call.id, "❌ لم تشترك بعد", show_alert=True)
        elif data == "main_menu":
            bot.delete_message(chat_id, call.message.message_id)
            send_main_menu(chat_id, call.from_user.first_name or "User")
        bot.answer_callback_query(call.id)
    except Exception as e:
        logger.error(f"Callback error: {str(e)}")

@bot.message_handler(func=lambda message: True)
def handle_all_messages(message):
    if check_subscription(message.from_user.id):
        bot.reply_to(message, "👋 استخدم /start للقائمة")

if __name__ == '__main__':
    try:
        init_database()
        logger.info("🚀 Bot started!")
        logger.info(f"Token: {BOT_TOKEN[:20]}...")
        bot.infinity_polling(timeout=10, long_polling_timeout=5)
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        sys.exit(1)
"""
        # استبدال القيم الديناميكية
        template = code.replace("BOT_TOKEN_PLACEHOLDER", bot_token)
        template = template.replace("ADMIN_ID_PLACEHOLDER", str(admin_id))
        template = template.replace("FORCE_CHANNEL_PLACEHOLDER", force_channel)
        
        return template
    
    def start_bot(self, bot_id: int, user_id: int) -> dict:
        """تشغيل البوت المعزول"""
        try:
            conn = sqlite3.connect(DATABASE_FILE)
            cursor = conn.cursor()
            cursor.execute('SELECT bot_dir, status FROM user_bots WHERE id = ? AND user_id = ?', (bot_id, user_id))
            result = cursor.fetchone()
            
            if not result:
                return {'success': False, 'message': 'البوت غير موجود'}
            
            bot_dir, status = result
            
            if status == 'running':
                return {'success': False, 'message': 'البوت يعمل بالفعل'}
            
            # تشغيل البوت في عملية منفصلة
            bot_file = os.path.join(bot_dir, "bot_main.py")
            process = subprocess.Popen(
                ['python', bot_file],
                cwd=bot_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # حفظ معلومات العملية
            if user_id not in self.running_bots:
                self.running_bots[user_id] = {}
            self.running_bots[user_id][bot_id] = process
            
            # تحديث قاعدة البيانات
            cursor.execute('UPDATE user_bots SET status = ?, process_id = ? WHERE id = ?', 
                          ('running', process.pid, bot_id))
            conn.commit()
            conn.close()
            
            return {'success': True, 'message': 'تم تشغيل البوت بنجاح'}
        except Exception as e:
            logger.error(f"Error starting bot: {str(e)}")
            return {'success': False, 'message': str(e)}
    
    def stop_bot(self, bot_id: int, user_id: int) -> dict:
        """إيقاف البوت"""
        try:
            if user_id in self.running_bots and bot_id in self.running_bots[user_id]:
                process = self.running_bots[user_id][bot_id]
                process.terminate()
                try:
                    process.wait(timeout=5)
                except:
                    process.kill()
                
                del self.running_bots[user_id][bot_id]
            
            conn = sqlite3.connect(DATABASE_FILE)
            cursor = conn.cursor()
            cursor.execute('UPDATE user_bots SET status = ?, process_id = NULL WHERE id = ? AND user_id = ?',
                          ('stopped', bot_id, user_id))
            conn.commit()
            conn.close()
            
            return {'success': True, 'message': 'تم إيقاف البوت'}
        except Exception as e:
            logger.error(f"Error stopping bot: {str(e)}")
            return {'success': False, 'message': str(e)}


    def show_my_isolated_bots(self, chat_id: int, user_id: int):
        """عرض بوتات المستخدم المعزولة"""
        bots = self.get_user_bots(user_id)

        if not bots:
            msg = "📭 <b>لا توجد بوتات</b>\n\n"
            msg += "يمكنك إنشاء بوت جديد مقابل 200 نقطة"
            keyboard = [[
                InlineKeyboardButton("➕ إنشاء بوت", callback_data="create_host_bot"),
                InlineKeyboardButton("🔙 رجوع", callback_data="main_menu")
            ]]
            bot.send_message(chat_id, msg, parse_mode='HTML', 
                           reply_markup=InlineKeyboardMarkup(keyboard))
            return

        msg = f"🤖 <b>بوتاتك المعزولة ({len(bots)})</b>\n\n"

        keyboard_buttons = []
        for user_bot in bots:
            status_icon = "🟢" if user_bot['status'] == 'running' else "🔴"
            msg += f"{status_icon} <b>البوت #{user_bot['id']}</b>\n"
            msg += f"• التوكن: <code>{user_bot['token']}</code>\n"
            msg += f"• الأدمن: <code>{user_bot['admin_id']}</code>\n"
            msg += f"• الحالة: {user_bot['status']}\n"
            msg += f"• تاريخ الإنشاء: {user_bot['created_at'][:10]}\n\n"

            row = []
            if user_bot['status'] == 'running':
                row.append(InlineKeyboardButton(f"⏹️ إيقاف #{user_bot['id']}", 
                          callback_data=f"stop_isolated_bot_{user_bot['id']}"))
            else:
                row.append(InlineKeyboardButton(f"▶️ تشغيل #{user_bot['id']}", 
                          callback_data=f"start_isolated_bot_{user_bot['id']}"))
            
            row.append(InlineKeyboardButton(f"🗑️ حذف #{user_bot['id']}", 
                      callback_data=f"delete_isolated_bot_{user_bot['id']}"))
            keyboard_buttons.append(row)

        keyboard_buttons.append([
            InlineKeyboardButton("➕ إنشاء بوت جديد", callback_data="create_host_bot"),
            InlineKeyboardButton("🔙 رجوع", callback_data="main_menu")
        ])

        bot.send_message(chat_id, msg, parse_mode='HTML', 
                       reply_markup=InlineKeyboardMarkup(keyboard_buttons))

    def start_isolated_bot(self, call, chat_id: int, user_id: int, bot_id: int):
        """تشغيل بوت معزول"""
        result = self.start_bot(bot_id, user_id)
        
        if result['success']:
            bot.answer_callback_query(call.id, "✅ تم تشغيل البوت")
            self.show_my_isolated_bots(chat_id, user_id)
        else:
            bot.answer_callback_query(call.id, f"❌ {result['message']}", show_alert=True)

    def stop_isolated_bot(self, call, chat_id: int, user_id: int, bot_id: int):
        """إيقاف بوت معزول"""
        result = self.stop_bot(bot_id, user_id)
        
        if result['success']:
            bot.answer_callback_query(call.id, "⏹️ تم إيقاف البوت")
            self.show_my_isolated_bots(chat_id, user_id)
        else:
            bot.answer_callback_query(call.id, f"❌ {result['message']}", show_alert=True)

    def delete_isolated_bot(self, call, chat_id: int, user_id: int, bot_id: int):
        """حذف بوت معزول"""
        result = self.delete_bot(bot_id, user_id)
        
        if result['success']:
            bot.answer_callback_query(call.id, "🗑️ تم حذف البوت")
            self.show_my_isolated_bots(chat_id, user_id)
        else:
            bot.answer_callback_query(call.id, f"❌ {result['message']}", show_alert=True)
    
    def get_user_bots(self, user_id: int):
        """الحصول على بوتات المستخدم"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('SELECT id, bot_token, admin_id, force_channel, status, created_at FROM user_bots WHERE user_id = ?', (user_id,))
        bots = cursor.fetchall()
        conn.close()
        
        return [{
            'id': bot[0],
            'token': bot[1][:20] + '...',
            'admin_id': bot[2],
            'force_channel': bot[3],
            'status': bot[4],
            'created_at': bot[5]
        } for bot in bots]
    
    def delete_bot(self, bot_id: int, user_id: int) -> dict:
        """حذف البوت"""
        try:
            # إيقاف البوت أولاً
            self.stop_bot(bot_id, user_id)
            
            conn = sqlite3.connect(DATABASE_FILE)
            cursor = conn.cursor()
            cursor.execute('SELECT bot_dir FROM user_bots WHERE id = ? AND user_id = ?', (bot_id, user_id))
            result = cursor.fetchone()
            
            if result:
                bot_dir = result[0]
                if os.path.exists(bot_dir):
                    shutil.rmtree(bot_dir)
                
                cursor.execute('DELETE FROM user_bots WHERE id = ? AND user_id = ?', (bot_id, user_id))
                conn.commit()
            
            conn.close()
            return {'success': True, 'message': 'تم حذف البوت'}
        except Exception as e:
            logger.error(f"Error deleting bot: {str(e)}")
            return {'success': False, 'message': str(e)}

class BotHandler:
    """Bot handler"""

    def __init__(self):
        ai_analyzer = AdvancedAIAnalyzer(GEMINI_API_KEY, DEEPSEEK_API_KEY) if (GEMINI_API_KEY or DEEPSEEK_API_KEY) else None
        self.security = UltraSecuritySystem(ai_analyzer)
        self.db = DatabaseManager()
        self.points_system = PointsSystem(self.db)
        self.project_manager = ProjectManager(self.db, self.security)
        self.message_manager = MessageManager(self.db)
        self.premium_system = PremiumSystem(self.db)
        self.ai_chat = AIChat(GEMINI_API_KEY)
        self.bot_speed = BotSpeedSystem(self.db)
        self.isolated_bot_manager = IsolatedBotManager(self.db)
        self.waiting_for_files = {}
        self.waiting_for_broadcast = {}
        self.waiting_for_add_points = {}
        self.waiting_for_feedback = {}
        self.user_last_message = {}
        self.waiting_for_ai_chat = {}
        self.waiting_for_bot_creation = {}
        self.waiting_for_api_key = {}

    def check_channel_subscription(self, user_id: int) -> bool:
        """Check if user subscribed to channel"""
        try:
            # Try with channel ID first
            member = bot.get_chat_member(FORCE_CHANNEL_ID, user_id)
            is_member = member.status in ['member', 'administrator', 'creator']
            logger.info(f"User {user_id} subscription check: {member.status} - is_member: {is_member}")
            return is_member
        except Exception as e:
            logger.error(f"Subscription check failed for user {user_id}: {str(e)}")
            # If failed, try with channel username
            try:
                member = bot.get_chat_member(FORCE_CHANNEL, user_id)
                is_member = member.status in ['member', 'administrator', 'creator']
                logger.info(f"User {user_id} subscription check (fallback): {member.status} - is_member: {is_member}")
                return is_member
            except Exception as e2:
                logger.error(f"Subscription fallback check also failed: {str(e2)}")
                return False

    def start(self, message):
        """Start command"""
        user_id = message.from_user.id
        chat_id = message.chat.id
        username = message.from_user.username or "No username"
        first_name = message.from_user.first_name or "User"

        # Check bot enabled status (skip for admins)
        settings = self.security.get_security_settings()
        if user_id not in ADMIN_IDS:
            if not settings.get('bot_enabled', True):
                bot.send_message(chat_id, "⏸️ <b>البوت متوقف حالياً</b>\n\nسيعود للعمل قريباً...", parse_mode='HTML')
                return
            
            if settings.get('maintenance_mode', False):
                maintenance_msg = settings.get('maintenance_message', 'البوت في وضع الصيانة حالياً 🔧')
                bot.send_message(chat_id, f"🔧 <b>{maintenance_msg}</b>", parse_mode='HTML')
                return

        # Check channel subscription (skip for admins)
        if user_id not in ADMIN_IDS and not self.check_channel_subscription(user_id):
            subscribe_msg = "<b>🔒 اشتراك إجباري</b>\n"
            subscribe_msg += "<b>⚠️ يجب الاشتراك في القناة للاستخدام:</b>\n"
            subscribe_msg += f"<b>📢 القناة:</b> {FORCE_CHANNEL}\n"
            subscribe_msg += "<b>👇 اضغط للاشتراك ثم ارجع واضغط تحقق</b>"
            keyboard = InlineKeyboardMarkup([
                [InlineKeyboardButton("📢 اشترك في القناة", url=f"https://t.me/{FORCE_CHANNEL[1:]}")],
                [InlineKeyboardButton("✅ تحقق من الاشتراك", callback_data="check_subscription")]
            ])
            bot.send_message(chat_id, subscribe_msg, parse_mode='HTML', reply_markup=keyboard)
            return

        user = self.db.get_user(user_id)

        if not user:
            self.db.create_user(user_id, username, first_name)

            if message.text.startswith('/start '):
                ref_code = message.text.split(' ')[1]

                conn = sqlite3.connect(DATABASE_FILE)
                cursor = conn.cursor()
                cursor.execute('SELECT user_id FROM users WHERE referral_code = ?', (ref_code,))
                referrer = cursor.fetchone()
                conn.close()

                if referrer and referrer[0] != user_id:
                    if self.points_system.process_referral(referrer[0], user_id):
                        try:
                            bot.send_message(referrer[0], f"🎉 <b>New referral!</b>\n\n<b>💰 +{REFERRAL_POINTS} points</b>", parse_mode='HTML')
                        except:
                            pass

        user_data = self.db.get_user(user_id)
        if user_data and user_data.get('is_banned'):
            bot.send_message(chat_id, "❌ You are banned from using this bot.")
            return

        self.send_welcome_message(chat_id, user_id, first_name, username)

    def send_welcome_message(self, chat_id: int, user_id: int, first_name: str, username: str):
        """Send welcome with profile picture"""
        points = self.points_system.get_user_points(user_id)
        user = self.db.get_user(user_id)

        # Get user profile photos
        try:
            profile_photos = bot.get_user_profile_photos(user_id, limit=1)
            if profile_photos.total_count > 0:
                photo = profile_photos.photos[0][0].file_id
            else:
                photo = None
        except:
            photo = None

        # Username display
        username_display = f"@{username}" if username else "لا يوجد"
        
        # Check if premium
        is_premium = user.get('is_premium', False)
        bot_speed = user.get('bot_speed', 'normal')
        
        # Premium status icons
        premium_icon = "💎" if is_premium else ""
        speed_icon = {"normal": "🐢", "turbo": "⚡", "ultra": "🚀"}.get(bot_speed, "🐢")

        if is_premium:
            welcome_msg = f"💎 <b>{first_name} {premium_icon}</b>\n"

            welcome_msg += f"🆔 <b>Telegram ID:</b> <code>{user_id}</code>\n"

            welcome_msg += f"👤 <b>Username:</b> {username_display}\n"

            welcome_msg += "━━━━━━━━━━━━━━━\n"

            welcome_msg += "✨ <b>WELCOME PREMIUM USER</b> ✨\n"

            welcome_msg += f"💰 <b>Points:</b> <code>{points}</code>\n"

            welcome_msg += f"📊 <b>Projects:</b> <code>{user.get('total_projects', 0)}</code>\n"

            welcome_msg += f"{speed_icon} <b>Speed:</b> <code>{bot_speed.upper()}</code>\n"

            welcome_msg += "📋 <b>Choose an option:</b>"
        else:
            welcome_msg = f"👤 <b>{first_name}</b>\n"

            welcome_msg += f"🆔 <b>Telegram ID:</b> <code>{user_id}</code>\n"

            welcome_msg += f"👤 <b>Username:</b> {username_display}\n"

            welcome_msg += "━━━━━━━━━━━━━━━\n"

            welcome_msg += f"<b>HELLO {first_name.upper()} TO FREE HOST</b>\n"

            welcome_msg += f"💰 <b>Points:</b> <code>{points}</code>\n"

            welcome_msg += f"📊 <b>Projects:</b> <code>{user.get('total_projects', 0)}</code>\n"

            welcome_msg += f"{speed_icon} <b>Speed:</b> <code>{bot_speed.upper()}</code>\n"

            welcome_msg += "📋 <b>Choose an option:</b>"

        keyboard_buttons = [
            [InlineKeyboardButton("📤 Upload File", callback_data="host_file"),
             InlineKeyboardButton("📦 Upload ZIP", callback_data="host_zip")],
            [InlineKeyboardButton("📂 My Projects", callback_data="my_projects"),
             InlineKeyboardButton("💰 Points", callback_data="my_points")],
            [InlineKeyboardButton("⚡ Bot Speed", callback_data="bot_speed_menu"),
             InlineKeyboardButton("📊 Stats", callback_data="my_stats")]
        ]
        
        # Add Premium/AI Chat button
        if is_premium:
            keyboard_buttons.append([InlineKeyboardButton("🤖 AI Chat", callback_data="ai_chat")])
            keyboard_buttons.append([InlineKeyboardButton("🏗️ Create Your Host Bot (200 pts)", callback_data="create_host_bot")])
            keyboard_buttons.append([InlineKeyboardButton("🤖 بوتاتي المعزولة", callback_data="my_isolated_bots")])
        else:
            keyboard_buttons.append([InlineKeyboardButton("💎 Upgrade to Premium (100 Points)", callback_data="upgrade_premium")])
        
        keyboard_buttons.extend([
            [InlineKeyboardButton("🧪 Test Bot Speed", callback_data="test_bot_speed")],
            [InlineKeyboardButton("📋 Logs", callback_data="show_logs"),
             InlineKeyboardButton("❓ Help", callback_data="help")],
            [InlineKeyboardButton("💬 Feedback", callback_data="send_feedback")]
        ])

        if user_id in ADMIN_IDS:
            keyboard_buttons.append([InlineKeyboardButton("👑 Admin Panel", callback_data="admin_panel")])

        # Delete old message if exists
        if user_id in self.user_last_message:
            try:
                bot.delete_message(chat_id, self.user_last_message[user_id])
            except:
                pass

        # Send with or without photo
        if photo:
            msg = bot.send_photo(
                chat_id,
                photo,
                caption=welcome_msg,
                parse_mode='HTML',
                reply_markup=InlineKeyboardMarkup(keyboard_buttons)
            )
        else:
            msg = bot.send_message(
                chat_id,
                welcome_msg,
                parse_mode='HTML',
                reply_markup=InlineKeyboardMarkup(keyboard_buttons)
            )

        self.user_last_message[user_id] = msg.message_id

    def handle_admin_command(self, message):
        """Admin command"""
        user_id = message.from_user.id
        chat_id = message.chat.id

        if user_id not in ADMIN_IDS:
            bot.send_message(chat_id, "❌ Access denied")
            return

        stats = self.db.get_system_stats()

        admin_msg += "<b>👑 Admin Panel</b>\n"


        admin_msg += "<b>📊 System Stats:</b>\n"


        admin_msg += f"• Users: {stats['total_users']}\n"


        admin_msg += f"• Total Projects: {stats['total_projects']}\n"


        admin_msg += f"• Running: {stats['running_projects']}"

        keyboard_buttons = [
            [InlineKeyboardButton("📢 Broadcast", callback_data="admin_broadcast"),
             InlineKeyboardButton("👥 Users", callback_data="admin_users")],
            [InlineKeyboardButton("💰 Add Points", callback_data="admin_add_points"),
             InlineKeyboardButton("💬 Feedback", callback_data="admin_feedback")],
            [InlineKeyboardButton("🔙 Back", callback_data="main_menu")]
        ]

        bot.send_message(
            chat_id,
            admin_msg,
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup(keyboard_buttons)
        )

    def handle_text(self, message):
        """Handle text"""
        user_id = message.from_user.id
        chat_id = message.chat.id

        # Check bot enabled and maintenance mode (skip for admins)
        settings = self.security.get_security_settings()
        if user_id not in ADMIN_IDS:
            if not settings.get('bot_enabled', True):
                bot.send_message(chat_id, "⏸️ <b>البوت متوقف حالياً</b>\n\nسيعود للعمل قريباً...", parse_mode='HTML')
                return
            
            if settings.get('maintenance_mode', False):
                maintenance_msg = settings.get('maintenance_message', 'البوت في وضع الصيانة حالياً 🔧')
                bot.send_message(chat_id, f"🔧 <b>{maintenance_msg}</b>", parse_mode='HTML')
                return

        user_data = self.db.get_user(user_id)
        if user_data and user_data.get('is_banned'):
            bot.send_message(chat_id, "❌ You are banned.")
            return

        # Initialize waiting_for_ai_training if not exists
        if not hasattr(self, 'waiting_for_ai_training'):
            self.waiting_for_ai_training = {}
        if not hasattr(self, 'waiting_for_manual_file'):
            self.waiting_for_manual_file = {}

        # Handle API key update
        if user_id in self.waiting_for_api_key:
            api_key_type = self.waiting_for_api_key[user_id]
            new_key = message.text.strip()
            
            if api_key_type == 'gemini':
                if self.security.update_security_settings(gemini_api_key=new_key):
                    bot.send_message(chat_id, "✅ <b>تم تحديث Gemini API Key بنجاح!</b>\n\n🔒 المفتاح محفوظ بشكل مشفر", parse_mode='HTML')
                    # Update analyzer key
                    self.security.ai_analyzer.gemini_key = new_key
                else:
                    bot.send_message(chat_id, "❌ حدث خطأ أثناء التحديث", parse_mode='HTML')
            elif api_key_type == 'deepseek':
                if self.security.update_security_settings(deepseek_api_key=new_key):
                    bot.send_message(chat_id, "✅ <b>تم تحديث DeepSeek API Key بنجاح!</b>\n\n🔒 المفتاح محفوظ بشكل مشفر", parse_mode='HTML')
                    # Update analyzer key
                    self.security.ai_analyzer.deepseek_key = new_key
                else:
                    bot.send_message(chat_id, "❌ حدث خطأ أثناء التحديث", parse_mode='HTML')
            
            del self.waiting_for_api_key[user_id]
            return

        if user_id in self.waiting_for_broadcast:
            self.send_broadcast(message)
        elif user_id in self.waiting_for_add_points:
            self.add_points_to_user(message)
        elif user_id in self.waiting_for_feedback:
            self.send_feedback_to_admins(message)
        elif user_id in self.waiting_for_ai_training:
            self.train_ai_with_code(message)
        elif user_id in self.waiting_for_manual_file:
            self.process_manual_file_text(message)
        elif hasattr(self, 'waiting_for_ai_test') and user_id in self.waiting_for_ai_test:
            self.test_ai_with_code(message)
        elif user_id in self.waiting_for_ai_chat:
            if message.text == '/end':
                self.end_ai_chat(chat_id, user_id)
            else:
                response = self.ai_chat.chat(user_id, message.text)
                bot.send_message(chat_id, f"🤖 <b>AI:</b>\n\n{response}", parse_mode='HTML')
        elif user_id in self.waiting_for_bot_creation:
            self.handle_bot_creation(message)

    def train_ai_with_code(self, message):
        """Train AI with malicious code provided by admin"""
        user_id = message.from_user.id
        chat_id = message.chat.id

        if user_id not in ADMIN_IDS:
            return

        settings = self.security.get_security_settings()
        lang = settings.get('language', 'ar')

        code = message.text
        
        # Analyze the code
        wait_msg = bot.send_message(
            chat_id, 
            "⏳ جاري التحليل والتعلم..." if lang == 'ar' else "⏳ Analyzing and learning..."
        )

        # Security analysis
        security_check = self.security.analyze_code(code, "admin_training")
        
        # Store as malicious code regardless
        self.security.store_malicious_code(
            code,
            "Admin-Provided",
            security_check.get('blocked_patterns', ['admin_training']),
            'critical'
        )

        # Learn patterns from this code
        threading.Thread(
            target=self.security.learn_from_blocked_code,
            args=(code, security_check.get('blocked_patterns', []))
        ).start()

        if lang == 'ar':
            result_msg = "✅ <b>تم التدريب بنجاح!</b>\n"

            result_msg += "<b>📊 النتائج:</b>\n"

            result_msg += f"• الأنماط المكتشفة: {len(security_check.get('blocked_patterns', []))}\n"

            result_msg += f"• مستوى الخطورة: {security_check.get('risk_level', 'critical')}\n"

            result_msg += "• تم الحفظ في قاعدة البيانات ✓\n"

            result_msg += "• الذكاء يتعلم الآن... 🧠\n"

            result_msg += "<b>💡 الـ AI سيتطور تلقائياً!</b>"
        else:
            result_msg = "✅ <b>Training Successful!</b>\n"

            result_msg += "<b>📊 Results:</b>\n"

            result_msg += f"• Patterns detected: {len(security_check.get('blocked_patterns', []))}\n"

            result_msg += f"• Severity level: {security_check.get('risk_level', 'critical')}\n"

            result_msg += "• Saved to database ✓\n"

            result_msg += "• AI is learning now... 🧠\n"

            result_msg += "<b>💡 AI will auto-evolve!</b>"

        bot.edit_message_text(result_msg, chat_id, wait_msg.message_id, parse_mode='HTML')

        del self.waiting_for_ai_training[user_id]

    def test_ai_with_code(self, message):
        """Test AI with code (admin only)"""
        user_id = message.from_user.id
        chat_id = message.chat.id

        if user_id not in ADMIN_IDS:
            return

        settings = self.security.get_security_settings()
        lang = settings.get('language', 'ar')

        code = message.text
        
        wait_msg = bot.send_message(
            chat_id, 
            "⏳ جاري اختبار الـ AI..." if lang == 'ar' else "⏳ Testing AI..."
        )

        security_check = self.security.analyze_code(code, "ai_test")
        
        if lang == 'ar':
            result_msg = "🧪 <b>نتائج اختبار الذكاء الاصطناعي</b>\n"
            result_msg += "━━━━━━━━━━━━━━━━━━━\n\n"
            result_msg += f"<b>🔒 الحالة:</b> {'❌ خطير' if not security_check['safe'] else '✅ آمن'}\n"
            result_msg += f"<b>⚠️ مستوى الخطر:</b> {security_check.get('risk_level', 'low').upper()}\n"
            result_msg += f"<b>🔍 طريقة الكشف:</b> {security_check.get('detection_method', 'N/A')}\n\n"
            
            if security_check.get('blocked_patterns'):
                result_msg += "<b>🚫 الأنماط المكتشفة:</b>\n"
                for pattern in security_check['blocked_patterns'][:10]:
                    result_msg += f"• <code>{pattern[:100]}</code>\n"
                result_msg += "\n"
            
            if security_check.get('ai_analysis'):
                ai_result = security_check['ai_analysis']
                result_msg += "<b>🤖 تحليل AI:</b>\n"
                result_msg += f"• AI المستخدم: {ai_result.get('ai_provider', 'N/A')}\n"
                result_msg += f"• الثقة: {ai_result.get('confidence', 0) * 100:.1f}%\n"
                if ai_result.get('threats'):
                    result_msg += f"• تهديدات AI: {len(ai_result['threats'])}\n"
                result_msg += "\n"
            
            if security_check.get('warnings'):
                result_msg += "<b>⚠️ تحذيرات:</b>\n"
                for warning in security_check['warnings'][:3]:
                    result_msg += f"• {warning}\n"
            
            result_msg += "\n<b>💡 ملاحظة:</b> هذا اختبار فقط ولم يتم حفظ الكود"
        else:
            result_msg = "🧪 <b>AI Test Results</b>\n"
            result_msg += "━━━━━━━━━━━━━━━━━━━\n\n"
            result_msg += f"<b>🔒 Status:</b> {'❌ Dangerous' if not security_check['safe'] else '✅ Safe'}\n"
            result_msg += f"<b>⚠️ Risk Level:</b> {security_check.get('risk_level', 'low').upper()}\n"
            result_msg += f"<b>🔍 Detection Method:</b> {security_check.get('detection_method', 'N/A')}\n\n"
            
            if security_check.get('blocked_patterns'):
                result_msg += "<b>🚫 Detected Patterns:</b>\n"
                for pattern in security_check['blocked_patterns'][:10]:
                    result_msg += f"• <code>{pattern[:100]}</code>\n"
                result_msg += "\n"
            
            if security_check.get('ai_analysis'):
                ai_result = security_check['ai_analysis']
                result_msg += "<b>🤖 AI Analysis:</b>\n"
                result_msg += f"• AI Used: {ai_result.get('ai_provider', 'N/A')}\n"
                result_msg += f"• Confidence: {ai_result.get('confidence', 0) * 100:.1f}%\n"
                if ai_result.get('threats'):
                    result_msg += f"• AI Threats: {len(ai_result['threats'])}\n"
                result_msg += "\n"
            
            if security_check.get('warnings'):
                result_msg += "<b>⚠️ Warnings:</b>\n"
                for warning in security_check['warnings'][:3]:
                    result_msg += f"• {warning}\n"
            
            result_msg += "\n<b>💡 Note:</b> This is a test only, code was not saved"

        bot.edit_message_text(result_msg, chat_id, wait_msg.message_id, parse_mode='HTML')

        del self.waiting_for_ai_test[user_id]

    def send_broadcast(self, message):
        """Send broadcast"""
        user_id = message.from_user.id
        chat_id = message.chat.id

        if user_id not in ADMIN_IDS:
            return

        broadcast_text = message.text
        all_users = self.db.get_all_users()

        success_count = 0
        fail_count = 0

        for user in all_users:
            try:
                bot.send_message(user['user_id'], broadcast_text, parse_mode='HTML')
                success_count += 1
                time.sleep(0.05)
            except:
                fail_count += 1

        result_msg = f"<b>📢 Broadcast completed!</b>\n\n<b>✅ Sent:</b> {success_count}\n<b>❌ Failed:</b> {fail_count}"
        bot.send_message(chat_id, result_msg, parse_mode='HTML')

        del self.waiting_for_broadcast[user_id]

    def add_points_to_user(self, message):
        """Add points"""
        user_id = message.from_user.id
        chat_id = message.chat.id

        if user_id not in ADMIN_IDS:
            return

        try:
            points = int(message.text)
            target_user_id = self.waiting_for_add_points[user_id]

            self.db.update_points(target_user_id, points)

            bot.send_message(chat_id, f"<b>✅ Added {points} points to user {target_user_id}</b>", parse_mode='HTML')

            try:
                bot.send_message(target_user_id, f"<b>🎁 You received {points} points from admin!</b>", parse_mode='HTML')
            except:
                pass

        except ValueError:
            bot.send_message(chat_id, "❌ Invalid amount")

        if user_id in self.waiting_for_add_points:
            del self.waiting_for_add_points[user_id]

    def handle_document(self, message):
        """Handle document"""
        user_id = message.from_user.id
        chat_id = message.chat.id

        user_data = self.db.get_user(user_id)
        if user_data and user_data.get('is_banned'):
            bot.send_message(chat_id, "❌ You are banned.")
            return

        if user_id not in self.waiting_for_files:
            return

        file_type = self.waiting_for_files[user_id]['type']

        if file_type == 'python' and message.document.file_name.endswith('.py'):
            self.process_python_file(message)
        elif file_type == 'zip' and (message.document.file_name.endswith('.zip') or 
                                   'zip' in message.document.mime_type):
            self.process_zip_file(message)
        else:
            bot.send_message(chat_id, "❌ Invalid file type")

    def process_python_file(self, message):
        """Process Python file"""
        user_id = message.from_user.id
        chat_id = message.chat.id

        try:
            file_info = bot.get_file(message.document.file_id)
            downloaded_file = bot.download_file(file_info.file_path)

            if len(downloaded_file) > MAX_FILE_SIZE:
                bot.send_message(chat_id, "❌ File too large (max 20MB)")
                return

            try:
                content = downloaded_file.decode('utf-8')
            except:
                content = downloaded_file.decode('utf-8', errors='ignore')

            security_check = self.security.analyze_code(content, message.document.file_name)
            if not security_check['safe']:
                violations = self.security.record_violation(user_id)
                self.db.update_violations(user_id, violations)

                # Don't ban admins
                if violations >= 3 and user_id not in ADMIN_IDS:
                    self.db.ban_user(user_id)
                    bot.send_message(chat_id, "🚫 <b>BANNED</b> - Repeated security violations", parse_mode='HTML')
                    return

                blocked_msg = f"<b>🛡️ Security Alert - File Rejected!</b>\n\n"
                blocked_msg += f"<b>⚠️ Critical threats detected</b>\n\n"
                if security_check['blocked_patterns']:
                    blocked_msg += "<b>Blocked patterns:</b>\n"
                    for pattern in security_check['blocked_patterns'][:5]:
                        blocked_msg += f"• <code>{pattern}</code>\n"

                blocked_msg += f"\n<b>⚠️ Violations:</b> {violations}/3"
                blocked_msg += f"\n<b>🔐 Risk:</b> {security_check['risk_level'].upper()}"

                bot.send_message(chat_id, blocked_msg, parse_mode='HTML')
                return

            if not self.points_system.deduct_points(user_id, COST_PER_SCRIPT):
                bot.send_message(chat_id, "❌ Insufficient points")
                return

            project_name = message.document.file_name.replace('.py', '')
            files = {message.document.file_name: content}
            project_dir = self.project_manager.create_project(user_id, project_name, files)

            success_msg = "<b>✅ File hosted successfully!</b>\n\n"
            success_msg += f"<b>📁 Project:</b> <code>{project_name}</code>\n"
            success_msg += "<b>🔐 Encryption:</b> ✅ Enabled\n"
            success_msg += f"<b>💰 Cost:</b> <code>{COST_PER_SCRIPT}</code> points\n"
            success_msg += f"<b>📊 Balance:</b> <code>{self.points_system.get_user_points(user_id)}</code> points"

            keyboard_buttons = [
                [InlineKeyboardButton("⚡ Run", callback_data=f"restart_{project_dir}")],
                [InlineKeyboardButton("🔙 Menu", callback_data="main_menu")]
            ]

            bot.send_message(
                chat_id, 
                success_msg, 
                parse_mode='HTML',
                reply_markup=InlineKeyboardMarkup(keyboard_buttons)
            )

            self.project_manager.run_project(project_dir, message.document.file_name, user_id, chat_id)

        except Exception as e:
            logger.error(f"Error processing Python file: {str(e)}")
            bot.send_message(chat_id, f"❌ Error: {str(e)}")

        finally:
            if user_id in self.waiting_for_files:
                del self.waiting_for_files[user_id]

    def process_zip_file(self, message):
        """Process ZIP file"""
        user_id = message.from_user.id
        chat_id = message.chat.id

        try:
            file_info = bot.get_file(message.document.file_id)
            downloaded_file = bot.download_file(file_info.file_path)

            if len(downloaded_file) > MAX_FILE_SIZE:
                bot.send_message(chat_id, "❌ File too large (max 20MB)")
                return

            extracted_files = self.project_manager.extract_zip(user_id, downloaded_file)

            if not extracted_files:
                bot.send_message(chat_id, "❌ No valid Python files found")
                return

            for filename, content in extracted_files.items():
                security_check = self.security.analyze_code(content, filename)
                if not security_check['safe']:
                    violations = self.security.record_violation(user_id)
                    self.db.update_violations(user_id, violations)

                    # Don't ban admins
                    if violations >= 3 and user_id not in ADMIN_IDS:
                        self.db.ban_user(user_id)
                        bot.send_message(chat_id, "🚫 <b>BANNED</b> - Repeated violations", parse_mode='HTML')
                        return

                    blocked_msg = f"<b>🛡️ Threat in <code>{filename}</code>:</b>\n\n"
                    if security_check['blocked_patterns']:
                        blocked_msg += "<b>Blocked:</b>\n"
                        for pattern in security_check['blocked_patterns'][:3]:
                            blocked_msg += f"• <code>{pattern}</code>\n"

                    blocked_msg += f"\n<b>⚠️ Violations:</b> {violations}/3"

                    bot.send_message(chat_id, blocked_msg, parse_mode='HTML')
                    return

            if not self.points_system.deduct_points(user_id, COST_PER_ZIP):
                bot.send_message(chat_id, "❌ Insufficient points")
                return

            project_name = message.document.file_name.replace('.zip', '')
            self.project_manager.request_main_file_selection(user_id, extracted_files, chat_id, project_name)

        except Exception as e:
            logger.error(f"Error processing ZIP: {str(e)}")
            bot.send_message(chat_id, f"❌ Error: {str(e)}")

        finally:
            if user_id in self.waiting_for_files:
                del self.waiting_for_files[user_id]

    def handle_callback(self, call):
        """Handle callback"""
        user_id = call.from_user.id
        chat_id = call.message.chat.id
        data = call.data

        user_data = self.db.get_user(user_id)
        if user_data and user_data.get('is_banned'):
            bot.answer_callback_query(call.id, "❌ Banned")
            return

        try:
            if data == "check_subscription":
                if self.check_channel_subscription(user_id):
                    bot.answer_callback_query(call.id, "✅ تم التحقق بنجاح!")
                    try:
                        bot.delete_message(chat_id, call.message.message_id)
                    except:
                        pass
                    self.send_welcome_message(chat_id, user_id, call.from_user.first_name or "User", call.from_user.username or "No username")
                else:
                    bot.answer_callback_query(call.id, "❌ لم تشترك بعد في القناة", show_alert=True)
                return

            # Check subscription for all other callbacks
            if user_id not in ADMIN_IDS and not self.check_channel_subscription(user_id):
                bot.answer_callback_query(call.id, "❌ يجب الاشتراك في القناة أولاً", show_alert=True)
                return

            elif data == "main_menu":
                self.send_welcome_message(chat_id, user_id, call.from_user.first_name or "User", call.from_user.username or "No username")

            elif data == "host_file":
                self.start_host_file(chat_id, user_id)

            elif data == "host_zip":
                self.start_host_zip(chat_id, user_id)

            elif data == "my_projects":
                self.show_my_projects(chat_id, user_id)

            elif data == "my_points":
                self.show_my_points(chat_id, user_id)

            elif data == "my_stats":
                self.show_my_stats(chat_id, user_id)

            elif data == "daily_reward":
                self.claim_daily_reward(chat_id, user_id)

            elif data == "show_logs":
                self.show_logs(chat_id, user_id)

            elif data == "help":
                self.show_help(chat_id, user_id)

            elif data == "admin_panel":
                if user_id in ADMIN_IDS:
                    self.handle_admin_panel(chat_id, user_id)

            elif data.startswith("restart_"):
                project_dir = data.replace("restart_", "")
                self.restart_project(chat_id, user_id, project_dir)

            elif data.startswith("stop_"):
                project_dir = data.replace("stop_", "")
                self.stop_project(chat_id, user_id, project_dir)

            elif data.startswith("delete_"):
                project_dir = data.replace("delete_", "")
                self.delete_project(chat_id, user_id, project_dir)

            elif data.startswith("mainfile_page_"):
                page = int(data.replace("mainfile_page_", ""))
                if user_id in self.project_manager.waiting_for_main_file:
                    try:
                        bot.delete_message(chat_id, call.message.message_id)
                    except:
                        pass
                    project_data = self.project_manager.waiting_for_main_file[user_id]
                    self.project_manager.request_main_file_selection(
                        user_id, 
                        project_data['files'], 
                        chat_id, 
                        project_data['project_name'],
                        page
                    )

            elif data.startswith("select_main_"):
                file_index = int(data.replace("select_main_", ""))
                self.select_main_file(chat_id, user_id, file_index)

            elif data == "admin_broadcast":
                if user_id in ADMIN_IDS:
                    self.request_broadcast(chat_id, user_id)

            elif data == "admin_users":
                if user_id in ADMIN_IDS:
                    self.show_admin_users(chat_id, user_id)

            elif data == "admin_add_points":
                if user_id in ADMIN_IDS:
                    self.show_add_points_menu(chat_id, user_id)

            elif data == "admin_feedback":
                if user_id in ADMIN_IDS:
                    self.show_admin_feedback(chat_id, user_id)

            elif data == "send_feedback":
                self.waiting_for_feedback[user_id] = True
                keyboard = InlineKeyboardMarkup([[InlineKeyboardButton("❌ إلغاء", callback_data="main_menu")]])
                bot.send_message(chat_id, "<b>💬 أرسل رسالتك الآن:</b>\n\n<i>اكتب ملاحظاتك أو اقتراحاتك وسيتم إرسالها للمطور</i>", parse_mode='HTML', reply_markup=keyboard)

            elif data == "bot_speed_menu":
                self.show_bot_speed_menu(chat_id, user_id)

            elif data.startswith("set_speed_"):
                speed = data.replace("set_speed_", "")
                self.set_bot_speed(call, chat_id, user_id, speed)

            elif data == "test_bot_speed":
                self.test_bot_speed(chat_id, user_id)

            elif data == "create_host_bot":
                self.start_create_bot(chat_id, user_id)

            elif data == "upgrade_premium":
                self.upgrade_to_premium(chat_id, user_id)

            elif data == "ai_chat":
                self.start_ai_chat(chat_id, user_id)

            elif data == "ai_chat_end":
                self.end_ai_chat(chat_id, user_id)

            elif data.startswith("admin_ban_"):
                if user_id in ADMIN_IDS:
                    target_user_id = int(data.replace("admin_ban_", ""))
                    self.db.ban_user(target_user_id)
                    bot.answer_callback_query(call.id, f"✅ User {target_user_id} banned")
                    self.show_admin_users(chat_id, user_id)

            elif data.startswith("admin_unban_"):
                if user_id in ADMIN_IDS:
                    target_user_id = int(data.replace("admin_unban_", ""))
                    self.db.unban_user(target_user_id)
                    bot.answer_callback_query(call.id, f"✅ User {target_user_id} unbanned")
                    self.show_admin_users(chat_id, user_id)

            elif data.startswith("admin_add_points_"):
                if user_id in ADMIN_IDS:
                    target_user_id = int(data.replace("admin_add_points_", ""))
                    self.waiting_for_add_points[user_id] = target_user_id
                    bot.send_message(chat_id, "💰 <b>Enter points:</b>", parse_mode='HTML')

            elif data == "admin_security":
                if user_id in ADMIN_IDS:
                    self.show_security_control(chat_id, user_id)

            elif data == "admin_ai_training":
                if user_id in ADMIN_IDS:
                    self.show_ai_training(chat_id, user_id)

            elif data == "admin_language":
                if user_id in ADMIN_IDS:
                    self.toggle_language(chat_id, user_id)

            elif data == "admin_security_stats":
                if user_id in ADMIN_IDS:
                    self.show_security_stats(chat_id, user_id)

            elif data == "admin_upload_file":
                if user_id in ADMIN_IDS:
                    self.show_upload_file_to_ai(chat_id, user_id)

            elif data == "admin_auto_learning":
                if user_id in ADMIN_IDS:
                    self.show_auto_learning_control(chat_id, user_id)

            elif data == "admin_learning_history":
                if user_id in ADMIN_IDS:
                    self.show_learning_history(chat_id, user_id)

            elif data == "admin_ai_activity":
                if user_id in ADMIN_IDS:
                    self.show_ai_activity(chat_id, user_id)

            elif data == "toggle_auto_learning":
                if user_id in ADMIN_IDS:
                    ai = self.security.ai_analyzer
                    ai.auto_learning_enabled = not ai.auto_learning_enabled
                    status = "🟢 مفعّل" if ai.auto_learning_enabled else "🔴 معطّل"
                    bot.answer_callback_query(call.id, f"التعلم التلقائي: {status}")
                    self.show_auto_learning_control(chat_id, user_id)

            elif data == "run_auto_learning":
                if user_id in ADMIN_IDS:
                    bot.answer_callback_query(call.id, "⏳ بدء التعلم...")
                    threading.Thread(target=self.security.ai_analyzer.auto_learn_background, daemon=True).start()
                    bot.send_message(chat_id, "✅ تم بدء التعلم التلقائي! سيصلك إشعار عند اكتمال كل مصدر.")

            elif data.startswith("set_security_mode_"):
                if user_id in ADMIN_IDS:
                    mode = data.replace("set_security_mode_", "")
                    self.set_security_mode(call, chat_id, user_id, mode)

            elif data == "admin_ai_test":
                if user_id in ADMIN_IDS:
                    self.show_ai_test(chat_id, user_id)

            elif data == "confirm_premium":
                if self.premium_system.upgrade_to_premium(user_id):
                    welcome_msg = "💎💎💎 <b>WELCOME TO PREMIUM!</b> 💎💎💎\n"

                    welcome_msg += "✨ You are now a Premium user! ✨\n"

                    welcome_msg += "<b>Your Premium Features:</b>\n"

                    welcome_msg += "🤖 AI Chat Assistant - ACTIVATED\n"

                    welcome_msg += "🚀 Ultra Speed - ACTIVATED\n"

                    welcome_msg += "📊 Unlimited Projects - ACTIVATED\n"

                    welcome_msg += "🛡️ Advanced Security - ACTIVATED\n"

                    welcome_msg += "💬 Priority Support - ACTIVATED\n"

                    welcome_msg += "<b>🎉 Enjoy your exclusive experience!</b>"
                    bot.send_message(chat_id, welcome_msg, parse_mode='HTML')
                    self.send_welcome_message(chat_id, user_id, call.from_user.first_name or "User", call.from_user.username or "No username")
                else:
                    bot.send_message(chat_id, "❌ Upgrade failed. Please try again.")

            elif data == "skip_channel":
                if user_id in self.waiting_for_bot_creation:
                    creation_data = self.waiting_for_bot_creation[user_id]
                    creation_data['force_channel'] = ""
                    self.finalize_bot_creation(chat_id, user_id, creation_data)

            elif data == "my_isolated_bots":
                self.isolated_bot_manager.show_my_isolated_bots(chat_id, user_id)

            elif data.startswith("start_isolated_bot_"):
                bot_id = int(data.replace("start_isolated_bot_", ""))
                self.isolated_bot_manager.start_isolated_bot(call, chat_id, user_id, bot_id)

            elif data.startswith("stop_isolated_bot_"):
                bot_id = int(data.replace("stop_isolated_bot_", ""))
                self.isolated_bot_manager.stop_isolated_bot(call, chat_id, user_id, bot_id)

            elif data.startswith("delete_isolated_bot_"):
                bot_id = int(data.replace("delete_isolated_bot_", ""))
                self.isolated_bot_manager.delete_isolated_bot(call, chat_id, user_id, bot_id)

            elif data.startswith("view_logs_"):
                project_name = data.replace("view_logs_", "")
                self.show_project_logs(chat_id, user_id, project_name)

            elif data == "admin_api_keys":
                if user_id in ADMIN_IDS:
                    self.show_api_keys_panel(chat_id, user_id)

            elif data == "admin_maintenance":
                if user_id in ADMIN_IDS:
                    self.toggle_maintenance_mode(call, chat_id, user_id)

            elif data == "admin_toggle_bot":
                if user_id in ADMIN_IDS:
                    self.toggle_bot_enabled(call, chat_id, user_id)
            
            elif data == "update_gemini_key":
                if user_id in ADMIN_IDS:
                    self.waiting_for_api_key[user_id] = 'gemini'
                    bot.send_message(chat_id, "<b>🔑 أرسل Gemini API Key الجديد:</b>\n\n<i>سيتم تشفيره وحفظه بشكل آمن</i>", parse_mode='HTML')

            elif data == "update_deepseek_key":
                if user_id in ADMIN_IDS:
                    self.waiting_for_api_key[user_id] = 'deepseek'
                    bot.send_message(chat_id, "<b>🔑 أرسل DeepSeek API Key الجديد:</b>\n\n<i>سيتم تشفيره وحفظه بشكل آمن</i>", parse_mode='HTML')

            bot.answer_callback_query(call.id)

        except Exception as e:
            logger.error(f"Callback error: {str(e)}")
            bot.answer_callback_query(call.id, "❌ Error")

    def handle_admin_panel(self, chat_id: int, user_id: int):
        """Admin panel"""
        stats = self.db.get_system_stats()
        security_stats = self.security.get_malicious_codes_stats()
        settings = self.security.get_security_settings()

        lang = settings.get('language', 'ar')
        if lang == 'ar':
            admin_msg = "<b>🔱 لوحة الإدارة</b>\n\n"
            admin_msg += "<b>📊 إحصائيات النظام:</b>\n"
            admin_msg += f"• المستخدمين: {stats['total_users']}\n"
            admin_msg += f"• المشاريع: {stats['total_projects']}\n"
            admin_msg += f"• قيد التشغيل: {stats['running_projects']}\n\n"
            admin_msg += "<b>🛡️ إحصائيات الحماية:</b>\n"
            admin_msg += f"• أكواد ضارة محفوظة: {security_stats['total_codes']}\n"
            admin_msg += f"• عدد الاكتشافات: {security_stats['total_detections']}\n"
            admin_msg += f"• وضع الحماية: {settings['mode']}\n"
            admin_msg += "• اللغة: العربية 🇸🇦"
        else:
            admin_msg = "<b>🔱 Admin Panel</b>\n\n"
            admin_msg += "<b>📊 System Stats:</b>\n"
            admin_msg += f"• Users: {stats['total_users']}\n"
            admin_msg += f"• Projects: {stats['total_projects']}\n"
            admin_msg += f"• Running: {stats['running_projects']}\n\n"
            admin_msg += "<b>🛡️ Security Stats:</b>\n"
            admin_msg += f"• Stored Malicious Codes: {security_stats['total_codes']}\n"
            admin_msg += f"• Total Detections: {security_stats['total_detections']}\n"
            admin_msg += f"• Protection Mode: {settings['mode']}\n"
            admin_msg += "• Language: English 🇺🇸"

        # Get maintenance and bot status
        maintenance_status = "🟢 عادي" if not settings.get('maintenance_mode', False) else "🔧 صيانة"
        bot_status = "🟢 يعمل" if settings.get('bot_enabled', True) else "⏸️ موقف"
        
        admin_msg += f"\n<b>⚙️ حالة البوت:</b>\n"
        admin_msg += f"• الصيانة: {maintenance_status}\n"
        admin_msg += f"• الحالة: {bot_status}\n"
        
        keyboard_buttons = [
            [InlineKeyboardButton("🛡️ Security Control" if lang == 'en' else "🛡️ التحكم بالحماية", callback_data="admin_security"),
             InlineKeyboardButton("🧠 AI Training" if lang == 'en' else "🧠 تدريب الذكاء", callback_data="admin_ai_training")],
            [InlineKeyboardButton("🧪 TEST AI" if lang == 'en' else "🧪 اختبار AI", callback_data="admin_ai_test"),
             InlineKeyboardButton("📁 Upload File to AI" if lang == 'en' else "📁 رفع ملف للـ AI", callback_data="admin_upload_file")],
            [InlineKeyboardButton("🤖 Auto Learning" if lang == 'en' else "🤖 التعلم التلقائي", callback_data="admin_auto_learning"),
             InlineKeyboardButton("📚 Learning History" if lang == 'en' else "📚 سجل التعلم", callback_data="admin_learning_history")],
            [InlineKeyboardButton("🔍 AI Activity" if lang == 'en' else "🔍 نشاط AI", callback_data="admin_ai_activity"),
             InlineKeyboardButton("📊 Security Stats" if lang == 'en' else "📊 إحصائيات الحماية", callback_data="admin_security_stats")],
            [InlineKeyboardButton("🔑 API Keys" if lang == 'en' else "🔑 مفاتيح API", callback_data="admin_api_keys"),
             InlineKeyboardButton("🔧 Maintenance" if lang == 'en' else "🔧 وضع الصيانة", callback_data="admin_maintenance")],
            [InlineKeyboardButton(f"{'⏸️ Stop Bot' if settings.get('bot_enabled', True) else '▶️ Enable Bot'}" if lang == 'en' else f"{'⏸️ إيقاف البوت' if settings.get('bot_enabled', True) else '▶️ تشغيل البوت'}", callback_data="admin_toggle_bot"),
             InlineKeyboardButton("📢 Broadcast", callback_data="admin_broadcast")],
            [InlineKeyboardButton("🌐 Language" if lang == 'en' else "🌐 اللغة", callback_data="admin_language"),
             InlineKeyboardButton("👥 Users" if lang == 'en' else "👥 المستخدمين", callback_data="admin_users")],
            [InlineKeyboardButton("💰 Add Points" if lang == 'en' else "💰 إضافة نقاط", callback_data="admin_add_points"),
             InlineKeyboardButton("💬 Feedback", callback_data="admin_feedback")],
            [InlineKeyboardButton("🔙 Back" if lang == 'en' else "🔙 رجوع", callback_data="main_menu")]
        ]

        msg_id = self.message_manager.send_or_edit(
            chat_id,
            user_id,
            admin_msg,
            self.user_last_message.get(user_id),
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup(keyboard_buttons)
        )
        self.user_last_message[user_id] = msg_id

    def request_broadcast(self, chat_id: int, user_id: int):
        """Request broadcast"""
        self.waiting_for_broadcast[user_id] = True
        bot.send_message(chat_id, "<b>📢 Send broadcast:</b>", parse_mode='HTML')

    def show_admin_users(self, chat_id: int, user_id: int):
        """Show users"""
        users = self.db.get_all_users()

        users_msg = f"<b>👥 Total Users: {len(users)}</b>\n\n"

        keyboard_buttons = []
        for i, user in enumerate(users[:10]):
            ban_status = "🚫" if user['is_banned'] else "✅"
            users_msg += f"<b>{i+1}. {user['first_name']}</b>\n"
            users_msg += f"   ID: {user['user_id']}\n"
            users_msg += f"   {ban_status} Points: {user['points']}\n"
            users_msg += f"   Projects: {user['total_projects']}\n\n"

            if not user['is_banned']:
                keyboard_buttons.append([
                    InlineKeyboardButton(f"🚫 Ban {user['first_name']}", callback_data=f"admin_ban_{user['user_id']}")
                ])
            else:
                keyboard_buttons.append([
                    InlineKeyboardButton(f"✅ Unban {user['first_name']}", callback_data=f"admin_unban_{user['user_id']}")
                ])

        keyboard_buttons.append([InlineKeyboardButton("🔙 Back", callback_data="admin_panel")])

        bot.send_message(chat_id, users_msg, parse_mode='HTML', 
                        reply_markup=InlineKeyboardMarkup(keyboard_buttons))

    def show_add_points_menu(self, chat_id: int, user_id: int):
        """Show add points"""
        users = self.db.get_all_users()

        users_msg = "<b>💰 Select user:</b>\n\n"

        keyboard_buttons = []
        for i, user in enumerate(users[:10]):
            users_msg += f"{i+1}. <b>{user['first_name']}</b> ({user['points']} pts)\n"
            keyboard_buttons.append([
                InlineKeyboardButton(f"Add to {user['first_name']}", callback_data=f"admin_add_points_{user['user_id']}")
            ])

        keyboard_buttons.append([InlineKeyboardButton("🔙 Back", callback_data="admin_panel")])

        bot.send_message(chat_id, users_msg, parse_mode='HTML',
                        reply_markup=InlineKeyboardMarkup(keyboard_buttons))

    def select_main_file(self, chat_id: int, user_id: int, file_index: int):
        """Select main file"""
        if user_id not in self.project_manager.waiting_for_main_file:
            bot.send_message(chat_id, "❌ Selection expired")
            return

        project_data = self.project_manager.waiting_for_main_file[user_id]
        files = project_data['files']
        project_name = project_data['project_name']
        file_index_map = project_data.get('file_index_map', {})

        if file_index not in file_index_map:
            bot.send_message(chat_id, "❌ Invalid file")
            return

        selected_file = file_index_map[file_index]

        project_dir = self.project_manager.create_project(user_id, project_name, files, selected_file)

        success_msg = "<b>✅ Project hosted!</b>\n\n"
        success_msg += f"<b>📁 Project:</b> <code>{project_name}</code>\n"
        success_msg += f"<b>📄 Main:</b> <code>{selected_file}</code>\n"
        success_msg += f"<b>📊 Files:</b> <code>{len(files)}</code>\n"
        success_msg += "<b>🔐 Encrypted:</b> ✅\n"
        success_msg += f"<b>💰 Cost:</b> {COST_PER_ZIP} pts\n"
        success_msg += f"<b>📈 Balance:</b> {self.points_system.get_user_points(user_id)} pts"

        keyboard_buttons = [
            [InlineKeyboardButton("⚡ Run", callback_data=f"restart_{project_dir}")],
            [InlineKeyboardButton("🔙 Menu", callback_data="main_menu")]
        ]

        bot.send_message(
            chat_id, 
            success_msg, 
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup(keyboard_buttons)
        )

        self.project_manager.run_project(project_dir, selected_file, user_id, chat_id)

        del self.project_manager.waiting_for_main_file[user_id]

    def start_host_file(self, chat_id: int, user_id: int):
        """Start file upload"""
        if not self.points_system.has_enough_points(user_id, COST_PER_SCRIPT):
            self.show_insufficient_points(chat_id, user_id, COST_PER_SCRIPT)
            return

        self.waiting_for_files[user_id] = {'type': 'python'}

        msg = "<b>📁 Upload Python File</b>\n\n"
        msg += "<b>🔐 Security: Multi-layer protection</b>\n\n"
        msg += "<b>📤 Upload your file now</b>"

        bot.send_message(chat_id, msg, parse_mode='HTML',
                                reply_markup=InlineKeyboardMarkup([
                                    [InlineKeyboardButton("🔙 Back", callback_data="main_menu")]
                                ]))

    def start_host_zip(self, chat_id: int, user_id: int):
        """Start ZIP upload"""
        if not self.points_system.has_enough_points(user_id, COST_PER_ZIP):
            self.show_insufficient_points(chat_id, user_id, COST_PER_ZIP)
            return

        self.waiting_for_files[user_id] = {'type': 'zip'}

        msg = "<b>📦 Upload ZIP Project</b>\n\n"
        msg += "<b>🔐 Security: Advanced scanning</b>\n\n"
        msg += "<b>📤 Upload your ZIP now</b>"

        bot.send_message(chat_id, msg, parse_mode='HTML',
                                reply_markup=InlineKeyboardMarkup([
                                    [InlineKeyboardButton("🔙 Back", callback_data="main_menu")]
                                ]))

    def show_my_projects(self, chat_id: int, user_id: int):
        """Show projects"""
        projects = self.project_manager.get_user_projects(user_id)

        if not projects:
            msg_id = self.message_manager.send_or_edit(
                chat_id,
                user_id,
                "📭 No projects found",
                self.user_last_message.get(user_id)
            )
            self.user_last_message[user_id] = msg_id
            return

        projects_msg = f"<b>📂 Your Projects ({len(projects)})</b>\n\n"

        keyboard_buttons = []
        for project in projects:
            status_icon = "🟢" if project['status'] == 'running' else "🔴"
            encrypt_icon = "🔐" if project.get('is_encrypted') else "🔓"
            projects_msg += f"{status_icon} {encrypt_icon} <b>{project['project_name']}</b>\n"
            projects_msg += f"<b>📄 Main:</b> <code>{project['main_file']}</code>\n"
            projects_msg += f"<b>⚡ Status:</b> {project['status']} | <b>Runs:</b> {project.get('total_runs', 0)}\n\n"

            row_buttons = []
            if project['status'] == 'running':
                row_buttons.append(InlineKeyboardButton("⏹️ Stop", callback_data=f"stop_{project['project_dir']}"))
            else:
                row_buttons.append(InlineKeyboardButton("⚡ Run", callback_data=f"restart_{project['project_dir']}"))

            row_buttons.append(InlineKeyboardButton("🗑️ Delete", callback_data=f"delete_{project['project_dir']}"))
            keyboard_buttons.append(row_buttons)

            keyboard_buttons.append([InlineKeyboardButton(f"📊 View Logs - {project['project_name']}", 
                                                          callback_data=f"view_logs_{project['project_name']}")])

        keyboard_buttons.append([InlineKeyboardButton("🔙 Back", callback_data="main_menu")])

        msg_id = self.message_manager.send_or_edit(
            chat_id, 
            user_id, 
            projects_msg,
            self.user_last_message.get(user_id),
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup(keyboard_buttons)
        )
        self.user_last_message[user_id] = msg_id

    def show_my_points(self, chat_id: int, user_id: int):
        """Show points"""
        user = self.db.get_user(user_id)
        if not user:
            bot.send_message(chat_id, "❌ User not found")
            return

        points = user['points']
        referral_stats = self.db.get_referral_stats(user_id)

        points_msg = "<b>💰 Points System</b>\n\n"
        points_msg += f"<b>📊 Balance:</b> <code>{points}</code> points\n\n"
        points_msg += "<b>👥 Referrals:</b>\n"
        points_msg += f"• Total: <code>{referral_stats['total_referrals']}</code>\n"
        points_msg += f"• Earned: <code>{referral_stats['points_earned']}</code> pts\n\n"
        points_msg += "<b>🔗 Your Link:</b>\n"
        points_msg += f"<code>https://t.me/{(bot.get_me()).username}?start={user['referral_code']}</code>\n\n"
        points_msg += f"<b>💡 {REFERRAL_POINTS} pts per referral!</b>"

        msg_id = self.message_manager.send_or_edit(
            chat_id, 
            user_id, 
            points_msg,
            self.user_last_message.get(user_id),
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🎁 Daily", callback_data="daily_reward")],
                [InlineKeyboardButton("🔙 Back", callback_data="main_menu")]
            ])
        )
        self.user_last_message[user_id] = msg_id

    def show_my_stats(self, chat_id: int, user_id: int):
        """Show stats"""
        user = self.db.get_user(user_id)
        if not user:
            bot.send_message(chat_id, "❌ User not found")
            return

        stats_msg = "<b>📊 Your Statistics</b>\n\n"
        stats_msg += f"<b>💰 Points:</b> {user['points']}\n"
        stats_msg += f"<b>📁 Projects:</b> {user.get('total_projects', 0)}\n"
        stats_msg += f"<b>🎁 Daily Claims:</b> {user.get('daily_count', 0)}\n"
        stats_msg += f"<b>⚠️ Violations:</b> {user.get('violations', 0)}/3\n"
        stats_msg += f"<b>📅 Joined:</b> {user.get('join_date', 'Unknown')[:10]}"

        msg_id = self.message_manager.send_or_edit(
            chat_id,
            user_id,
            stats_msg,
            self.user_last_message.get(user_id),
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 Back", callback_data="main_menu")]
            ])
        )
        self.user_last_message[user_id] = msg_id

    def claim_daily_reward(self, chat_id: int, user_id: int):
        """Claim daily"""
        user = self.db.get_user(user_id)
        if not user:
            bot.send_message(chat_id, "❌ User not found")
            return

        if self.points_system.claim_daily_reward(user_id):
            points = self.points_system.get_user_points(user_id)
            msg_id = self.message_manager.send_or_edit(
                chat_id, 
                user_id,
                f"<b>🎁 Daily claimed!</b>\n\n<b>💰 +{DAILY_POINTS} pts</b>\n<b>📊 Total:</b> {points} pts",
                self.user_last_message.get(user_id),
                parse_mode='HTML',
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 Back", callback_data="main_menu")]
                ])
            )
            self.user_last_message[user_id] = msg_id
        else:
            last_daily = user.get('last_daily')
            if last_daily:
                try:
                    last_time = datetime.fromisoformat(last_daily)
                    next_claim = last_time + timedelta(hours=24)
                    now = datetime.now()
                    remaining = next_claim - now

                    if remaining.total_seconds() > 0:
                        hours = int(remaining.total_seconds() // 3600)
                        minutes = int((remaining.total_seconds() % 3600) // 60)
                        remaining_msg = f"<b>⏳ Wait:</b> {hours}h {minutes}m"
                    else:
                        remaining_msg = "⚠️ Try again"
                except:
                    remaining_msg = "⚠️ Try again"
            else:
                remaining_msg = "⚠️ Try again"

            msg_id = self.message_manager.send_or_edit(
                chat_id, 
                user_id,
                f"<b>❌ Already claimed!</b>\n\n{remaining_msg}",
                self.user_last_message.get(user_id),
                parse_mode='HTML',
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🔙 Back", callback_data="main_menu")]
                ])
            )
            self.user_last_message[user_id] = msg_id

    def show_help(self, chat_id: int, user_id: int):
        """Show help"""
        help_msg = "<b>🤖 Bot Guide</b>\n\n"
        help_msg += "<b>📋 Usage:</b>\n"
        help_msg += "1. Upload Python file (single)\n"
        help_msg += "2. Upload ZIP (multiple files)\n"
        help_msg += "3. Manage projects\n"
        help_msg += "4. Earn points via referrals\n\n"
        help_msg += "<b>💰 Prices:</b>\n"
        help_msg += f"• File: {COST_PER_SCRIPT} pts\n"
        help_msg += f"• ZIP: {COST_PER_ZIP} pts\n\n"
        help_msg += "<b>🎁 Earn:</b>\n"
        help_msg += f"• Daily: {DAILY_POINTS} pts\n"
        help_msg += f"• Referral: {REFERRAL_POINTS} pts\n\n"
        help_msg += "<b>🔧 Features:</b>\n"
        help_msg += "• Max 20MB files\n"
        help_msg += "• Python only\n"
        help_msg += "• Multi-layer security\n"
        help_msg += "• File encryption\n"
        help_msg += "• AI analysis\n\n"
        help_msg += "<b>📞 Contact:</b>\n"
        help_msg += f"{DEVELOPER_USERNAME}"

        msg_id = self.message_manager.send_or_edit(
            chat_id, 
            user_id, 
            help_msg,
            self.user_last_message.get(user_id),
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 Back", callback_data="main_menu")]
            ])
        )
        self.user_last_message[user_id] = msg_id

    def show_logs(self, chat_id: int, user_id: int):
        """Show logs"""
        logs = self.db.get_user_logs(user_id, 20)

        if not logs:
            msg_id = self.message_manager.send_or_edit(
                chat_id,
                user_id,
                "📭 No logs",
                self.user_last_message.get(user_id)
            )
            self.user_last_message[user_id] = msg_id
            return

        logs_msg = "<b>📊 Logs (Latest 20)</b>\n\n"

        for log in logs[:20]:
            log_type = log[3]
            message = log[4][:50]

            logs_msg += f"<b>{log_type}:</b> <code>{message}</code>\n"

        msg_id = self.message_manager.send_or_edit(
            chat_id,
            user_id,
            logs_msg,
            self.user_last_message.get(user_id),
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔙 Back", callback_data="main_menu")]
            ])
        )
        self.user_last_message[user_id] = msg_id

    def restart_project(self, chat_id: int, user_id: int, project_dir: str):
        """Restart project"""
        projects = self.project_manager.get_user_projects(user_id)
        project = next((p for p in projects if p['project_dir'] == project_dir), None)

        if not project:
            bot.send_message(chat_id, "❌ Project not found")
            return

        self.project_manager.stop_project(project_dir, chat_id)

        if self.project_manager.run_project(project_dir, project['main_file'], user_id, chat_id):
            bot.send_message(chat_id, "🔄 Project restarted")
        else:
            bot.send_message(chat_id, "❌ Failed to restart")

    def stop_project(self, chat_id: int, user_id: int, project_dir: str):
        """Stop project"""
        if self.project_manager.stop_project(project_dir, chat_id):
            bot.send_message(chat_id, "⏹️ Project stopped")
        else:
            bot.send_message(chat_id, "❌ Failed to stop")

    def delete_project(self, chat_id: int, user_id: int, project_dir: str):
        """Delete project"""
        if self.project_manager.delete_project(user_id, project_dir, chat_id):
            bot.send_message(chat_id, "🗑️ Project deleted")
        else:
            bot.send_message(chat_id, "❌ Failed to delete")

    def show_insufficient_points(self, chat_id: int, user_id: int, required_points: int):
        """Show insufficient"""
        current_points = self.points_system.get_user_points(user_id)

        msg = "<b>❌ Insufficient points!</b>\n\n"
        msg += f"<b>💰 Required:</b> {required_points} pts\n"
        msg += f"<b>📊 Current:</b> {current_points} pts\n\n"
        msg += "<b>💡 Earn more:</b>\n"
        msg += "• 🎁 Daily reward\n"
        msg += "• 👥 Referrals"
        
        bot.send_message(
            chat_id, 
            msg, 
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("💰 Points", callback_data="my_points"),
                 InlineKeyboardButton("🎁 Daily", callback_data="daily_reward")],
                [InlineKeyboardButton("🔙 Back", callback_data="main_menu")]
            ])
        )

    def process_manual_file_text(self, message):
        """Process manual file content for AI learning"""
        user_id = message.from_user.id
        chat_id = message.chat.id

        if user_id not in ADMIN_IDS:
            return

        wait_msg = bot.send_message(chat_id, "⏳ جاري تحليل الملف مع DeepSeek...")

        # Analyze with AI
        result = self.security.ai_analyzer.analyze_manual_file(message.text, "manual_input.txt")

        if result:
            msg = "✅ <b>تم التحليل بنجاح!</b>\n\n"
            msg += "<b>📊 النتائج:</b>\n"
            msg += f"• نوع التهديد: {result.get('threat_type', 'Unknown')}\n"
            msg += f"• الخطورة: {result.get('severity', 'Unknown')}\n"
            msg += f"• الأنماط المستخرجة: {len(result.get('patterns', []))}\n\n"
            msg += "<b>📝 التفسير:</b>\n"
            msg += f"{result.get('explanation', 'No explanation')[:300]}\n\n"
            msg += "<b>✅ تم حفظ الأنماط في قاعدة البيانات!</b>"
            
            bot.edit_message_text(msg, chat_id, wait_msg.message_id, parse_mode='HTML')
            
            # Store patterns
            for pattern in result.get('patterns', []):
                self.security.save_learned_pattern(pattern)
        else:
            bot.edit_message_text("❌ فشل التحليل", chat_id, wait_msg.message_id)

        del self.waiting_for_manual_file[user_id]

    def show_upload_file_to_ai(self, chat_id: int, user_id: int):
        """Show upload file interface"""
        msg = "<b>📁 رفع ملف للتعلم اليدوي</b>\n\n"
        msg += "<b>📝 كيف يعمل:</b>\n"
        msg += "1. أرسل محتوى الملف كنص\n"
        msg += "2. سيحلله الـ AI مع DeepSeek\n"
        msg += "3. سيستخرج الأنماط الخطيرة\n"
        msg += "4. سيحفظها تلقائياً\n\n"
        msg += "<b>👇 أرسل المحتوى الآن:</b>"

        keyboard = [[InlineKeyboardButton("❌ إلغاء", callback_data="admin_panel")]]
        bot.send_message(chat_id, msg, parse_mode='HTML', reply_markup=InlineKeyboardMarkup(keyboard))
        
        if not hasattr(self, 'waiting_for_manual_file'):
            self.waiting_for_manual_file = {}
        self.waiting_for_manual_file[user_id] = True

    def show_auto_learning_control(self, chat_id: int, user_id: int):
        """Show auto learning control panel"""
        ai_analyzer = self.security.ai_analyzer
        status = "🟢 مفعّل" if ai_analyzer.auto_learning_enabled else "🔴 معطّل"

        msg = "<b>🤖 التعلم التلقائي</b>\n\n"
        msg += f"<b>الحالة:</b> {status}\n\n"
        msg += "<b>📚 المصادر:</b>\n"
        msg += "• Wikipedia - معلومات أمنية\n"
        msg += "• GitHub - أكواد ضارة حقيقية\n"
        msg += "• Reddit - مناقشات الأمن السيبراني\n"
        msg += "• Google Search - نتائج بحث متقدمة\n\n"
        msg += "<b>⚡ الـ AI يتعلم تلقائياً كل ساعة!</b>\n"
        msg += "<b>📩 سيصلك إشعار عند كل تعلم جديد</b>"

        keyboard = [
            [InlineKeyboardButton("🟢 تفعيل" if not ai_analyzer.auto_learning_enabled else "🔴 تعطيل", 
                                callback_data="toggle_auto_learning")],
            [InlineKeyboardButton("▶️ تشغيل الآن", callback_data="run_auto_learning")],
            [InlineKeyboardButton("🔙 رجوع", callback_data="admin_panel")]
        ]
        bot.send_message(chat_id, msg, parse_mode='HTML', reply_markup=InlineKeyboardMarkup(keyboard))

    def show_learning_history(self, chat_id: int, user_id: int):
        """Show learning history"""
        try:
            with open(self.security.ai_analyzer.learning_history_file, 'r') as f:
                history = json.load(f)
            
            msg = "<b>📚 سجل التعلم</b>\n\n"
            msg += "<b>📊 الإحصائيات:</b>\n"
            msg += f"• إجمالي الأنماط: {history.get('total_patterns', 0)}\n"
            msg += f"• آخر تعلم: {history.get('last_learning', 'Never')[:19]}\n\n"
            msg += "<b>🎯 حسب المصدر:</b>"

            for source, count in history.get('sources_learned', {}).items():
                icon = {'wikipedia': '📖', 'github': '💻', 'reddit': '🌐', 'manual_files': '📁', 'google_search': '🔍'}.get(source, '📌')
                msg += f"\n{icon} {source}: {count}"

            msg += "\n\n<b>📝 آخر 5 أحداث:</b>\n"

            for event in history.get('learning_events', [])[:5]:
                msg += f"\n⏰ {event['timestamp'][:19]}"
                msg += f"\n📚 {event['source']} - {event['patterns_count']} patterns"
                msg += f"\n💬 {event['summary'][:80]}\n"

            keyboard = [[InlineKeyboardButton("🔄 تحديث", callback_data="admin_learning_history")],
                       [InlineKeyboardButton("🔙 رجوع", callback_data="admin_panel")]]
            bot.send_message(chat_id, msg, parse_mode='HTML', reply_markup=InlineKeyboardMarkup(keyboard))
        except:
            bot.send_message(chat_id, "❌ لا يوجد سجل تعلم بعد")

    def show_ai_activity(self, chat_id: int, user_id: int):
        """Show real-time AI activity"""
        msg = "<b>🔍 نشاط AI الحي</b>\n\n"
        msg += "<b>✅ يتم تتبع جميع أنشطة AI:</b>\n\n"
        msg += "• كل تحليل كود\n"
        msg += "• كل تعلم جديد\n"
        msg += "• كل نمط مكتشف\n"
        msg += "• كل مصدر تعلم\n\n"
        msg += "<b>📩 الإشعارات الفورية:</b>\n"
        msg += "سيصلك إشعار فوري عند:\n"
        msg += "✓ اكتشاف نمط جديد\n"
        msg += "✓ التعلم من مصدر جديد\n"
        msg += "✓ تحديث قاعدة البيانات\n"
        msg += "✓ تطور AI تلقائي\n\n"
        msg += "<b>🔔 كل شيء تحت السيطرة!</b>"

        keyboard = [[InlineKeyboardButton("🔙 رجوع", callback_data="admin_panel")]]
        bot.send_message(chat_id, msg, parse_mode='HTML', reply_markup=InlineKeyboardMarkup(keyboard))

    def show_project_logs(self, chat_id: int, user_id: int, project_name: str):
        """Show project logs with formatting"""
        logs_msg = self.project_manager.get_project_logs(user_id, project_name, 30)

        bot.send_message(
            chat_id,
            logs_msg,
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🔄 Refresh", callback_data=f"view_logs_{project_name}")],
                [InlineKeyboardButton("🔙 Back", callback_data="my_projects")]
            ])
        )

    def show_feedback_panel(self, chat_id: int, user_id: int):
        """Show feedback panel - User side"""
        feedback_msg = "<b>💬 Submit Feedback</b>\n\n"
        feedback_msg += "<b>💡 نحن نقدر رأيك!</b>\n"
        feedback_msg += "شارك اقتراحاتك أو أبلغ عن أي مشاكل\n\n"
        feedback_msg += "<b>👇 اضغط لإرسال رسالتك</b>"
        
        keyboard_buttons = [
            [InlineKeyboardButton("✍️ إرسال رسالة", callback_data="send_feedback")],
            [InlineKeyboardButton("🔙 Back", callback_data="main_menu")]
        ]
        msg_id = self.message_manager.send_or_edit(
            chat_id,
            user_id,
            feedback_msg,
            self.user_last_message.get(user_id),
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup(keyboard_buttons)
        )
        self.user_last_message[user_id] = msg_id

    def show_admin_feedback(self, chat_id: int, user_id: int):
        """Show feedback panel - Admin side"""
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                username TEXT,
                message TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        cursor.execute('SELECT * FROM feedback ORDER BY created_at DESC LIMIT 10')
        feedbacks = cursor.fetchall()
        conn.close()

        if not feedbacks:
            bot.send_message(chat_id, "<b>📭 لا توجد رسائل feedback</b>", parse_mode='HTML')
            return

        feedback_msg = "<b>💬 Feedback Messages (Latest 10)</b>\n\n"
        for fb in feedbacks:
            feedback_msg += f"<b>👤 User:</b> {fb[2]} (ID: {fb[1]})\n"
            feedback_msg += f"<b>📝 Message:</b> <code>{fb[3][:200]}</code>\n"
            feedback_msg += f"<b>📅 Date:</b> {fb[4][:16]}\n\n"

        keyboard = InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Back", callback_data="admin_panel")]])
        bot.send_message(chat_id, feedback_msg, parse_mode='HTML', reply_markup=keyboard)

    def send_feedback_to_admins(self, message):
        """Send feedback to admins"""
        user_id = message.from_user.id
        chat_id = message.chat.id
        username = message.from_user.username or message.from_user.first_name
        first_name = message.from_user.first_name or "User"

        # Save to database
        conn = sqlite3.connect(DATABASE_FILE)
        cursor = conn.cursor()
        
        # Create table if not exists
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                username TEXT,
                message TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        cursor.execute('''
            INSERT INTO feedback (user_id, username, message)
            VALUES (?, ?, ?)
        ''', (user_id, username, message.text))
        conn.commit()
        conn.close()

        # Send to all admins
        for admin_id in ADMIN_IDS:
            try:
                admin_msg = "<b>💬 New Feedback!</b>\n\n"
                admin_msg += f"<b>👤 From:</b> {first_name} (@{username if username else 'No username'})\n"
                admin_msg += f"<b>🆔 ID:</b> <code>{user_id}</code>\n"
                admin_msg += f"<b>📝 Message:</b>\n<code>{message.text}</code>"
                
                bot.send_message(admin_id, admin_msg, parse_mode='HTML')
            except Exception as e:
                logger.error(f"Failed to send feedback to admin {admin_id}: {str(e)}")

        keyboard = InlineKeyboardMarkup([[InlineKeyboardButton("🔙 القائمة الرئيسية", callback_data="main_menu")]])
        bot.send_message(chat_id, "<b>✅ تم إرسال رسالتك بنجاح!</b>\n\n<b>شكراً لك 💙</b>\n\n<i>سيتم الرد عليك قريباً</i>", parse_mode='HTML', reply_markup=keyboard)

        if user_id in self.waiting_for_feedback:
            del self.waiting_for_feedback[user_id]

    def show_bot_speed_menu(self, chat_id: int, user_id: int):
        """Show bot speed menu"""
        user = self.db.get_user(user_id)
        current_speed = user.get('bot_speed', 'normal')
        is_premium = user.get('is_premium', False)

        speed_msg = "<b>BOT SPEED SYSTEM</b>\n\n"
        speed_msg += "<b>Current Speed:</b> " + current_speed.upper() + "\n\n"
        speed_msg += "<b>Normal:</b> Standard speed (Free)\n"
        speed_msg += "<b>Turbo:</b> 2x faster (Free)\n"
        speed_msg += "<b>Ultra:</b> 3x faster (Premium Only)\n\n"
        speed_msg += "Choose your speed:"

        keyboard_buttons = [
            [InlineKeyboardButton(f"{'✅ ' if current_speed == 'normal' else ''}🐢 Normal", callback_data="set_speed_normal")],
            [InlineKeyboardButton(f"{'✅ ' if current_speed == 'turbo' else ''}⚡ Turbo", callback_data="set_speed_turbo")]
        ]

        if is_premium:
            keyboard_buttons.append([InlineKeyboardButton(f"{'✅ ' if current_speed == 'ultra' else ''}🚀 Ultra (Premium)", callback_data="set_speed_ultra")])
        else:
            keyboard_buttons.append([InlineKeyboardButton("🔒 Ultra (Need Premium)", callback_data="upgrade_premium")])

        keyboard_buttons.append([InlineKeyboardButton("🔙 Back", callback_data="main_menu")])

        msg_id = self.message_manager.send_or_edit(
            chat_id,
            user_id,
            speed_msg,
            self.user_last_message.get(user_id),
            parse_mode='HTML',
            reply_markup=InlineKeyboardMarkup(keyboard_buttons)
        )
        self.user_last_message[user_id] = msg_id

    def set_bot_speed(self, call, chat_id: int, user_id: int, speed: str):
        """Set bot speed"""
        if self.bot_speed.set_speed(user_id, speed):
            bot.answer_callback_query(call.id, f"✅ Speed set to {speed.upper()}")
            self.show_bot_speed_menu(chat_id, user_id)
        else:
            bot.answer_callback_query(call.id, "❌ Premium required for Ultra speed", show_alert=True)

    def test_bot_speed(self, chat_id: int, user_id: int):
        """Test bot speed"""
        user = self.db.get_user(user_id)
        speed = user.get('bot_speed', 'normal')

        wait_msg = bot.send_message(chat_id, "⏳ Testing bot speed...")

        start_time = time.time()
        
        # Simulate speed test
        speed_multiplier = {"normal": 1, "turbo": 2, "ultra": 3}.get(speed, 1)
        test_duration = 1.0 / speed_multiplier

        time.sleep(test_duration)

        end_time = time.time()
        response_time = (end_time - start_time) * 1000

        result_msg = "<b>SPEED TEST RESULTS</b>\n\n"
        result_msg += f"<b>Current Speed:</b> {speed.upper()}\n"
        result_msg += f"<b>Response Time:</b> {response_time:.0f}ms\n"
        result_msg += f"<b>Multiplier:</b> x{speed_multiplier}\n\n"
        result_msg += 'Premium Speed!' if speed == 'ultra' else 'Great performance!'

        bot.edit_message_text(result_msg, chat_id, wait_msg.message_id, parse_mode='HTML')

    def upgrade_to_premium(self, chat_id: int, user_id: int):
        """Upgrade to premium"""
        user = self.db.get_user(user_id)
        
        if user.get('is_premium'):
            bot.send_message(chat_id, "💎 You are already a Premium user!")
            return

        if user['points'] < PREMIUM_COST:
            needed = PREMIUM_COST - user['points']
            bot.send_message(chat_id, f"❌ Not enough points!\n\n<b>Need:</b> {needed} more points", parse_mode='HTML')
            return

        # Upgrade confirmation
        keyboard = [
            [InlineKeyboardButton("✅ Yes, Upgrade!", callback_data="confirm_premium")],
            [InlineKeyboardButton("❌ Cancel", callback_data="main_menu")]
        ]

        upgrade_msg = "<b>UPGRADE TO PREMIUM</b>\n\n"
        upgrade_msg += f"<b>Cost:</b> {PREMIUM_COST} points\n"
        upgrade_msg += f"<b>Your Points:</b> {user['points']} points\n\n"
        upgrade_msg += "<b>Premium Features:</b>\n"
        upgrade_msg += "AI Chat Assistant\n"
        upgrade_msg += "Ultra Speed (3x faster)\n"
        upgrade_msg += "Unlimited Projects\n"
        upgrade_msg += "Advanced Security\n"
        upgrade_msg += "Priority Support\n"
        upgrade_msg += "Exclusive Design\n\n"
        upgrade_msg += "Ready to upgrade?"

        bot.send_message(chat_id, upgrade_msg, parse_mode='HTML', reply_markup=InlineKeyboardMarkup(keyboard))

    def start_ai_chat(self, chat_id: int, user_id: int):
        """Start AI chat"""
        user = self.db.get_user(user_id)
        
        if not user.get('is_premium'):
            bot.send_message(chat_id, "💎 AI Chat is available for Premium users only!")
            return

        self.waiting_for_ai_chat[user_id] = True

        chat_msg = "🤖 <b>AI CHAT ASSISTANT</b>\n"


        chat_msg += "<b>Welcome to your AI Assistant!</b>\n"


        chat_msg += "I can help you with:\n"


        chat_msg += "• Programming questions\n"


        chat_msg += "• Code debugging\n"


        chat_msg += "• Project ideas\n"


        chat_msg += "• Technical support\n"


        chat_msg += "• And much more!\n"


        chat_msg += "Send me a message or type /end to exit."

        keyboard = [[InlineKeyboardButton("❌ End Chat", callback_data="ai_chat_end")]]
        bot.send_message(chat_id, chat_msg, parse_mode='HTML', reply_markup=InlineKeyboardMarkup(keyboard))

    def end_ai_chat(self, chat_id: int, user_id: int):
        """End AI chat"""
        if user_id in self.waiting_for_ai_chat:
            del self.waiting_for_ai_chat[user_id]
        
        self.ai_chat.end_session(user_id)
        bot.send_message(chat_id, "👋 AI Chat ended. Thanks for using the assistant!")
        self.send_welcome_message(chat_id, user_id, "", "")

    def start_create_bot(self, chat_id: int, user_id: int):
        """Start bot creation process"""
        user = self.db.get_user(user_id)
        
        if user['points'] < CREATE_BOT_COST:
            needed = CREATE_BOT_COST - user['points']
            bot.send_message(chat_id, f"❌ Not enough points!\n\n<b>Need:</b> {needed} more points\n<b>Cost:</b> {CREATE_BOT_COST} points", parse_mode='HTML')
            return

        self.waiting_for_bot_creation[user_id] = {'step': 'admin_id'}

        create_msg = "🤖 <b>CREATE YOUR HOST BOT</b>\n\n"
        create_msg += "<b>Cost:</b> 200 points\n\n"
        create_msg += "<b>Step 1/4:</b> Send your Telegram ID to be set as admin\n\n"
        create_msg += "<i>Example: 123456789</i>"

        keyboard = [[InlineKeyboardButton("❌ Cancel", callback_data="main_menu")]]
        bot.send_message(chat_id, create_msg, parse_mode='HTML', reply_markup=InlineKeyboardMarkup(keyboard))

    def handle_bot_creation(self, message):
        """Handle bot creation steps"""
        user_id = message.from_user.id
        chat_id = message.chat.id

        if user_id not in self.waiting_for_bot_creation:
            return

        creation_data = self.waiting_for_bot_creation[user_id]
        step = creation_data['step']

        if step == 'admin_id':
            try:
                admin_id = int(message.text)
                creation_data['admin_id'] = admin_id
                creation_data['step'] = 'bot_token'
                bot.send_message(chat_id, "<b>Step 2/4:</b> Send your Bot Token from @BotFather\n\n<i>Example: 123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11</i>", parse_mode='HTML')
            except:
                bot.send_message(chat_id, "❌ Invalid ID! Please send a valid number.")

        elif step == 'bot_token':
            creation_data['bot_token'] = message.text
            creation_data['step'] = 'force_channel'
            
            keyboard = [
                [InlineKeyboardButton("⏭️ Skip (Optional)", callback_data="skip_channel")],
                [InlineKeyboardButton("❌ Cancel", callback_data="main_menu")]
            ]
            bot.send_message(chat_id, "<b>Step 3/4:</b> Send force subscription channel link (Optional)\n\n<i>Example: @YourChannel</i>", parse_mode='HTML', reply_markup=InlineKeyboardMarkup(keyboard))

        elif step == 'force_channel':
            creation_data['force_channel'] = message.text
            self.finalize_bot_creation(chat_id, user_id, creation_data)

    def finalize_bot_creation(self, chat_id: int, user_id: int, creation_data: dict):
        """Finalize bot creation"""
        # Deduct points
        self.points_system.deduct_points(user_id, CREATE_BOT_COST)

        # إنشاء البوت المعزول
        result = self.isolated_bot_manager.create_user_bot(
            user_id,
            creation_data['bot_token'],
            creation_data['admin_id'],
            creation_data.get('force_channel', '')
        )

        if result['success']:
            success_msg = "✅ <b>تم إنشاء البوت بنجاح!</b>\n\n"
            success_msg += f"<b>💰 النقاط المستخدمة:</b> {CREATE_BOT_COST}\n"
            success_msg += f"<b>📊 الرصيد المتبقي:</b> {self.points_system.get_user_points(user_id)}\n\n"
            success_msg += "<b>معلومات البوت:</b>\n"
            success_msg += f"👤 معرف الأدمن: <code>{creation_data['admin_id']}</code>\n"
            success_msg += f"🤖 توكن البوت: <code>{creation_data['bot_token'][:20]}...</code>\n"
            success_msg += f"📢 القناة: {creation_data.get('force_channel', 'لا يوجد')}\n\n"
            success_msg += "<b>✨ البوت جاهز للتشغيل الآن!</b>\n"
            success_msg += "يمكنك إدارته من قسم 'بوتاتي'"

            keyboard = [[
                InlineKeyboardButton("🤖 بوتاتي", callback_data="my_isolated_bots"),
                InlineKeyboardButton("🔙 القائمة", callback_data="main_menu")
            ]]

            bot.send_message(chat_id, success_msg, parse_mode='HTML', 
                           reply_markup=InlineKeyboardMarkup(keyboard))
        else:
            bot.send_message(chat_id, f"❌ فشل إنشاء البوت: {result['message']}")

        del self.waiting_for_bot_creation[user_id]

        # Log the creation
        self.db.add_log(user_id, "BOT_CREATION", "CREATE", f"Created isolated bot for admin {creation_data['admin_id']}")

    def show_security_control(self, chat_id: int, user_id: int):
        """Show security control panel"""
        settings = self.security.get_security_settings()
        lang = settings.get('language', 'ar')
        current_mode = settings.get('mode', 'both')

        if lang == 'ar':
            control_msg = "🛡️ <b>التحكم في الحماية</b>\n"

            control_msg += f"<b>الوضع الحالي:</b> {current_mode}\n"

            control_msg += "<b>اختر نوع الحماية:</b>\n"

            control_msg += "🤖 <b>AI فقط:</b> حماية بالذكاء الاصطناعي فقط\n"

            control_msg += "📜 <b>Script فقط:</b> حماية بالـ Script فقط\n"

            control_msg += "🔒 <b>الاثنين:</b> حماية مزدوجة (AI + Script)\n"

            control_msg += "<b>💡 نصيحة:</b> الحماية المزدوجة هي الأفضل!"
        else:
            control_msg = "🛡️ <b>Security Control</b>\n"

            control_msg += f"<b>Current Mode:</b> {current_mode}\n"

            control_msg += "<b>Choose Protection Type:</b>\n"

            control_msg += "🤖 <b>AI Only:</b> AI-based protection only\n"

            control_msg += "📜 <b>Script Only:</b> Script-based protection only\n"

            control_msg += "🔒 <b>Both:</b> Double protection (AI + Script)\n"

            control_msg += "<b>💡 Tip:</b> Double protection is best!"

        keyboard_buttons = [
            [InlineKeyboardButton(
                f"{'✅ ' if current_mode == 'ai_only' else ''}🤖 AI Only" if lang == 'en' else f"{'✅ ' if current_mode == 'ai_only' else ''}🤖 AI فقط",
                callback_data="set_security_mode_ai_only"
            )],
            [InlineKeyboardButton(
                f"{'✅ ' if current_mode == 'script_only' else ''}📜 Script Only" if lang == 'en' else f"{'✅ ' if current_mode == 'script_only' else ''}📜 Script فقط",
                callback_data="set_security_mode_script_only"
            )],
            [InlineKeyboardButton(
                f"{'✅ ' if current_mode == 'both' else ''}🔒 Both" if lang == 'en' else f"{'✅ ' if current_mode == 'both' else ''}🔒 الاثنين",
                callback_data="set_security_mode_both"
            )],
            [InlineKeyboardButton("🔙 Back" if lang == 'en' else "🔙 رجوع", callback_data="admin_panel")]
        ]

        bot.send_message(chat_id, control_msg, parse_mode='HTML', 
                        reply_markup=InlineKeyboardMarkup(keyboard_buttons))

    def set_security_mode(self, call, chat_id: int, user_id: int, mode: str):
        """Set security mode"""
        if self.security.update_security_settings(mode=mode):
            settings = self.security.get_security_settings()
            lang = settings.get('language', 'ar')
            
            msg = f"✅ تم تغيير وضع الحماية إلى: {mode}" if lang == 'ar' else f"✅ Security mode changed to: {mode}"
            bot.answer_callback_query(call.id, msg)
            self.show_security_control(chat_id, user_id)
        else:
            bot.answer_callback_query(call.id, "❌ خطأ في التحديث" if lang == 'ar' else "❌ Update failed")

    def toggle_language(self, chat_id: int, user_id: int):
        """Toggle language between Arabic and English"""
        settings = self.security.get_security_settings()
        current_lang = settings.get('language', 'ar')
        new_lang = 'en' if current_lang == 'ar' else 'ar'
        
        if self.security.update_security_settings(language=new_lang):
            msg = "✅ Language changed to English 🇺🇸" if new_lang == 'en' else "✅ تم تغيير اللغة إلى العربية 🇸🇦"
            bot.send_message(chat_id, msg, parse_mode='HTML')
            self.handle_admin_panel(chat_id, user_id)
        else:
            bot.send_message(chat_id, "❌ Failed to change language")

    def toggle_maintenance_mode(self, call, chat_id: int, user_id: int):
        """Toggle maintenance mode on/off"""
        settings = self.security.get_security_settings()
        current_status = settings.get('maintenance_mode', False)
        new_status = not current_status
        
        if self.security.update_security_settings(maintenance_mode=new_status):
            lang = settings.get('language', 'ar')
            if lang == 'ar':
                msg = "✅ تم تفعيل وضع الصيانة 🔧" if new_status else "✅ تم إيقاف وضع الصيانة ✅"
            else:
                msg = "✅ Maintenance mode enabled 🔧" if new_status else "✅ Maintenance mode disabled ✅"
            bot.answer_callback_query(call.id, msg)
            self.handle_admin_panel(chat_id, user_id)
        else:
            bot.answer_callback_query(call.id, "❌ Error")

    def toggle_bot_enabled(self, call, chat_id: int, user_id: int):
        """Toggle bot enabled/disabled"""
        settings = self.security.get_security_settings()
        current_status = settings.get('bot_enabled', True)
        new_status = not current_status
        
        if self.security.update_security_settings(bot_enabled=new_status):
            lang = settings.get('language', 'ar')
            if lang == 'ar':
                msg = "✅ تم إيقاف البوت ⏸️" if not new_status else "✅ تم تشغيل البوت ▶️"
            else:
                msg = "✅ Bot stopped ⏸️" if not new_status else "✅ Bot enabled ▶️"
            bot.answer_callback_query(call.id, msg)
            self.handle_admin_panel(chat_id, user_id)
        else:
            bot.answer_callback_query(call.id, "❌ Error")

    def show_api_keys_panel(self, chat_id: int, user_id: int):
        """Show API keys management panel"""
        settings = self.security.get_security_settings()
        lang = settings.get('language', 'ar')
        
        if lang == 'ar':
            keys_msg = "🔑 <b>إدارة مفاتيح API</b>\n\n"
            keys_msg += "<b>📊 الحالة الحالية:</b>\n"
            
            gemini_key = settings.get('gemini_api_key')
            deepseek_key = settings.get('deepseek_api_key')
            
            keys_msg += f"• Gemini API: {'✅ محفوظ' if gemini_key else '❌ غير محفوظ'}\n"
            keys_msg += f"• DeepSeek API: {'✅ محفوظ' if deepseek_key else '❌ غير محفوظ'}\n\n"
            keys_msg += "<b>💡 ملاحظة:</b>\n"
            keys_msg += "• المفاتيح محفوظة بشكل مشفّر\n"
            keys_msg += "• يمكنك تحديثها في أي وقت\n"
            keys_msg += "• Gemini يُستخدم للتحليل الرئيسي\n"
            keys_msg += "• DeepSeek احتياطي + تعلم متقدم\n"
        else:
            keys_msg = "🔑 <b>API Keys Management</b>\n\n"
            keys_msg += "<b>📊 Current Status:</b>\n"
            
            gemini_key = settings.get('gemini_api_key')
            deepseek_key = settings.get('deepseek_api_key')
            
            keys_msg += f"• Gemini API: {'✅ Saved' if gemini_key else '❌ Not saved'}\n"
            keys_msg += f"• DeepSeek API: {'✅ Saved' if deepseek_key else '❌ Not saved'}\n\n"
            keys_msg += "<b>💡 Note:</b>\n"
            keys_msg += "• Keys are encrypted\n"
            keys_msg += "• Can be updated anytime\n"
            keys_msg += "• Gemini for main analysis\n"
            keys_msg += "• DeepSeek for backup + advanced learning\n"
        
        keyboard_buttons = [
            [InlineKeyboardButton(
                "🔄 Update Gemini Key" if lang == 'en' else "🔄 تحديث Gemini Key",
                callback_data="update_gemini_key"
            )],
            [InlineKeyboardButton(
                "🔄 Update DeepSeek Key" if lang == 'en' else "🔄 تحديث DeepSeek Key",
                callback_data="update_deepseek_key"
            )],
            [InlineKeyboardButton("🔙 Back" if lang == 'en' else "🔙 رجوع", callback_data="admin_panel")]
        ]
        
        bot.send_message(chat_id, keys_msg, parse_mode='HTML', 
                        reply_markup=InlineKeyboardMarkup(keyboard_buttons))

    def show_ai_training(self, chat_id: int, user_id: int):
        """Show AI training interface"""
        settings = self.security.get_security_settings()
        lang = settings.get('language', 'ar')
        
        if lang == 'ar':
            training_msg = "🧠 <b>تدريب الذكاء الاصطناعي</b>\n\n"
            training_msg += "<b>📝 أرسل الآن:</b>\n"
            training_msg += "كود ضار تريد أن يتعلمه الـ AI\n\n"
            training_msg += "<b>💡 كيف يعمل:</b>\n"
            training_msg += "1. أرسل الكود الضار\n"
            training_msg += "2. الـ AI سيحلله بدقة\n"
            training_msg += "3. سيتعلم الأنماط الخطيرة\n"
            training_msg += "4. سيحفظها في قاعدة البيانات\n"
            training_msg += "5. سيتطور تلقائياً\n\n"
            training_msg += "<b>⚡ التعلم الذاتي مفعّل!</b>"
        else:
            training_msg = "🧠 <b>AI Training</b>\n\n"
            training_msg += "<b>📝 Send now:</b>\n"
            training_msg += "Malicious code you want AI to learn\n\n"
            training_msg += "<b>💡 How it works:</b>\n"
            training_msg += "1. Send malicious code\n"
            training_msg += "2. AI will analyze it precisely\n"
            training_msg += "3. Learn dangerous patterns\n"
            training_msg += "4. Save to database\n"
            training_msg += "5. Auto-evolve\n\n"
            training_msg += "<b>⚡ Self-learning enabled!</b>"

        keyboard = [[InlineKeyboardButton("🔙 Back" if lang == 'en' else "🔙 رجوع", callback_data="admin_panel")]]
        bot.send_message(chat_id, training_msg, parse_mode='HTML', reply_markup=InlineKeyboardMarkup(keyboard))
        
        # Set waiting state for AI training
        self.waiting_for_ai_training = getattr(self, 'waiting_for_ai_training', {})
        self.waiting_for_ai_training[user_id] = True

    def show_security_stats(self, chat_id: int, user_id: int):
        """Show detailed security statistics"""
        stats = self.security.get_malicious_codes_stats()
        settings = self.security.get_security_settings()
        lang = settings.get('language', 'ar')
        
        if lang == 'ar':
            stats_msg = "📊 <b>إحصائيات الحماية المتقدمة</b>\n\n"
            stats_msg += "<b>🗄️ قاعدة البيانات:</b>\n"
            stats_msg += f"• أكواد ضارة محفوظة: {stats['total_codes']}\n"
            stats_msg += f"• إجمالي الاكتشافات: {stats['total_detections']}\n\n"
            stats_msg += "<b>🎯 حسب الخطورة:</b>\n"
        else:
            stats_msg = "📊 <b>Advanced Security Statistics</b>\n\n"
            stats_msg += "<b>🗄️ Database:</b>\n"
            stats_msg += f"• Stored Malicious Codes: {stats['total_codes']}\n"
            stats_msg += f"• Total Detections: {stats['total_detections']}\n\n"
            stats_msg += "<b>🎯 By Severity:</b>\n"

        for severity, count in stats.get('by_severity', {}).items():
            icon = {'critical': '🔴', 'high': '🟠', 'medium': '🟡', 'low': '🟢'}.get(severity, '⚪')
            stats_msg += f"{icon} {severity.capitalize()}: {count}\n"

        # Get learned patterns count
        learned_count = len(self.security.critical_patterns)
        stats_msg += f"\n<b>🧠 {'أنماط متعلمة' if lang == 'ar' else 'Learned Patterns'}:</b> {learned_count}\n"
        stats_msg += f"<b>🛡️ {'وضع الحماية' if lang == 'ar' else 'Protection Mode'}:</b> {settings['mode']}\n"

        keyboard = [[InlineKeyboardButton("🔙 Back" if lang == 'en' else "🔙 رجوع", callback_data="admin_panel")]]
        bot.send_message(chat_id, stats_msg, parse_mode='HTML', reply_markup=InlineKeyboardMarkup(keyboard))

    def show_ai_test(self, chat_id: int, user_id: int):
        """Show AI TEST interface for admin"""
        settings = self.security.get_security_settings()
        lang = settings.get('language', 'ar')
        
        if lang == 'ar':
            test_msg = "🧪 <b>اختبار الذكاء الاصطناعي المنفصل</b>\n\n"
            test_msg += "<b>📋 ماذا يفعل هذا الاختبار؟</b>\n"
            test_msg += "• يختبر الـ AI الخاص بك (Gemini + DeepSeek)\n"
            test_msg += "• يعطيك تقرير شامل عن الكود\n"
            test_msg += "• يوضح إذا كان الكود آمن أو خطير\n"
            test_msg += "• يكتشف الأنماط الضارة بذكاء\n\n"
            test_msg += "<b>📤 أرسل الآن:</b>\n"
            test_msg += "ملف Python (.py) أو كود نصي لاختباره\n\n"
            test_msg += "<b>💡 ملاحظة:</b>\n"
            test_msg += "• هذا الاختبار لن يحفظ الملف\n"
            test_msg += "• سيعطيك النتيجة فوراً\n"
            test_msg += "• مخصص للتطوير والتدريب فقط\n\n"
            test_msg += "<b>🔒 الوضع الحالي:</b> " + settings.get('mode', 'both')
        else:
            test_msg = "🧪 <b>AI Testing Interface</b>\n\n"
            test_msg += "<b>📋 What does this test do?</b>\n"
            test_msg += "• Tests your AI (Gemini + DeepSeek)\n"
            test_msg += "• Provides comprehensive code report\n"
            test_msg += "• Shows if code is safe or dangerous\n"
            test_msg += "• Intelligently detects malicious patterns\n\n"
            test_msg += "<b>📤 Send now:</b>\n"
            test_msg += "Python file (.py) or text code to test\n\n"
            test_msg += "<b>💡 Note:</b>\n"
            test_msg += "• This test won't save the file\n"
            test_msg += "• Results are instant\n"
            test_msg += "• For development and training only\n\n"
            test_msg += "<b>🔒 Current Mode:</b> " + settings.get('mode', 'both')

        keyboard = [[InlineKeyboardButton("🔙 Back" if lang == 'en' else "🔙 رجوع", callback_data="admin_panel")]]
        bot.send_message(chat_id, test_msg, parse_mode='HTML', reply_markup=InlineKeyboardMarkup(keyboard))
        
        self.waiting_for_ai_test = getattr(self, 'waiting_for_ai_test', {})
        self.waiting_for_ai_test[user_id] = True

handler = BotHandler()

@bot.message_handler(commands=['start'])
def start_command(message):
    handler.start(message)

@bot.message_handler(commands=['admin'])
def admin_command(message):
    handler.handle_admin_command(message)

@bot.message_handler(content_types=['text'])
def text_handler(message):
    handler.handle_text(message)

@bot.message_handler(content_types=['document'])
def document_handler(message):
    handler.handle_document(message)

@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    handler.handle_callback(call)

def auto_learning_scheduler():
    """Auto learning scheduler - runs every 2 hours"""
    while True:
        try:
            logger.info("⏰ Starting scheduled AI auto-learning...")
            if handler.security.ai_analyzer and handler.security.ai_analyzer.auto_learning_enabled:
                handler.security.ai_analyzer.auto_learn_background()
                logger.info("✅ Scheduled AI auto-learning completed!")
            time.sleep(7200)  # 2 hours
        except Exception as e:
            logger.error(f"Auto learning scheduler error: {str(e)}")
            time.sleep(7200)

if __name__ == '__main__':
    logger.info("Bot started with ULTRA SECURITY")
    logger.info("File encryption: ENABLED")
    logger.info("AI analysis: " + ("ENABLED" if GEMINI_API_KEY or DEEPSEEK_API_KEY else "DISABLED"))
    logger.info("Message editing: ENABLED")
    
    # Start auto-learning in background
    if GEMINI_API_KEY or DEEPSEEK_API_KEY:
        logger.info("🤖 Starting AI auto-learning scheduler...")
        threading.Thread(target=auto_learning_scheduler, daemon=True).start()
        logger.info("✅ AI will auto-learn every 2 hours!")
        
        # Run first learning immediately
        logger.info("🚀 Running first AI learning session...")
        threading.Thread(target=handler.security.ai_analyzer.auto_learn_background, daemon=True).start()
    
    bot.polling(none_stop=True, interval=0, timeout=60)